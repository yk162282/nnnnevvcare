package com.example.doctor_appointment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
