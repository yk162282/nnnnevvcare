class AppConstants {
  // Screen Padding
  static const double screenPaddingHorizontal = 16.0;
  static const double screenPaddingVertical = 20.0;
  static const double sectionSpacing = 24.0;

  // Input Fields
  static const double inputFieldHeight = 52.0;
  static const double inputFieldRadius = 12.0;
  static const double inputFieldBorderWidth = 1.0;

  // Buttons
  static const double primaryButtonHeight = 48.0;
  static const double primaryButtonRadius = 12.0;

  // Icons
  static const double iconSizeSmall = 16.0;
  static const double iconSizeMedium = 24.0;
  static const double iconSizeLarge = 32.0;
  static const double socialButtonSize = 44.0;

  // Text Sizes
  static const double textSizeSmall = 12.0;
  static const double textSizeMedium = 14.0;
  static const double textSizeLarge = 16.0;
  static const double textSizeXLarge = 18.0;
  static const double textSizeXXLarge = 20.0;
  static const double textSizeXXXLarge = 24.0;

  // Spacing
  static const double spacingXS = 4.0;
  static const double spacingS = 8.0;
  static const double spacingM = 16.0;
  static const double spacingL = 24.0;
  static const double spacingXL = 32.0;
  static const double spacingXXL = 48.0;

  // Avatar Sizes
  static const double avatarSizeSmall = 40.0;
  static const double avatarSizeMedium = 56.0;
  static const double avatarSizeLarge = 96.0;

  // OTP Input
  static const double otpInputWidth = 44.0;
  static const double otpInputHeight = 56.0;
  static const double otpInputRadius = 12.0;

  // Animation Durations
  static const Duration animationDurationFast = Duration(milliseconds: 200);
  static const Duration animationDurationNormal = Duration(milliseconds: 300);
  static const Duration animationDurationSlow = Duration(milliseconds: 500);

  // Splash Screen
  static const Duration splashDuration = Duration(milliseconds: 1500);

  // API Timeouts
  static const Duration apiTimeout = Duration(seconds: 30);
  static const Duration apiRetryDelay = Duration(seconds: 2);

  // Validation
  static const int passwordMinLength = 6;
  static const int phoneMinLength = 10;
  static const int nameMinLength = 2;

  // Social Login
  static const List<String> supportedSocialProviders = [
    'google',
    'facebook',
    'apple',
  ];
}
