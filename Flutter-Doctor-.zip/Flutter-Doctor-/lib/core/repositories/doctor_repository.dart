import '../networking/api_service_interface.dart';
import '../models/api_response.dart';
import '../models/doctor.dart';
import '../models/specialization.dart';

class DoctorRepository {
  final ApiServiceInterface _apiService;

  DoctorRepository(this._apiService);

  // Get all doctors
  Future<ApiResponse<List<Doctor>>> getAllDoctors() async {
    try {
      return await _apiService.getAllDoctors();
    } catch (e) {
      return ApiResponse.error('Failed to get doctors: $e');
    }
  }

  // Get doctor by ID
  Future<ApiResponse<Doctor>> getDoctorById(int id) async {
    try {
      return await _apiService.showDoctor(id);
    } catch (e) {
      return ApiResponse.error('Failed to get doctor: $e');
    }
  }

  // Filter doctors
  Future<ApiResponse<List<Doctor>>> filterDoctors({
    int? cityId,
    int? specializationId,
    double? minRating,
    bool? availableToday,
  }) async {
    try {
      return await _apiService.filterDoctors(
        cityId: cityId,
        specializationId: specializationId,
        minRating: minRating,
        availableToday: availableToday,
      );
    } catch (e) {
      return ApiResponse.error('Failed to filter doctors: $e');
    }
  }

  // Search doctors
  Future<ApiResponse<List<Doctor>>> searchDoctors(String query) async {
    try {
      if (query.trim().isEmpty) {
        return ApiResponse.success([]);
      }
      return await _apiService.searchDoctors(query.trim());
    } catch (e) {
      return ApiResponse.error('Failed to search doctors: $e');
    }
  }

  // Get all specializations
  Future<ApiResponse<List<Specialization>>> getAllSpecializations() async {
    try {
      return await _apiService.getAllSpecializations();
    } catch (e) {
      return ApiResponse.error('Failed to get specializations: $e');
    }
  }

  // Get specialization by ID
  Future<ApiResponse<Specialization>> getSpecializationById(int id) async {
    try {
      return await _apiService.showSpecialization(id);
    } catch (e) {
      return ApiResponse.error('Failed to get specialization: $e');
    }
  }

  // Get recommended doctors (top rated, available)
  Future<ApiResponse<List<Doctor>>> getRecommendedDoctors() async {
    try {
      final response = await _apiService.filterDoctors(
        minRating: 4.0,
        availableToday: true,
      );

      if (response.isSuccess && response.data != null) {
        // Sort by rating and take top 6
        final sortedDoctors = List<Doctor>.from(response.data!);
        sortedDoctors.sort((a, b) => (b.rating ?? 0).compareTo(a.rating ?? 0));
        return ApiResponse.success(sortedDoctors.take(6).toList());
      }

      return response;
    } catch (e) {
      return ApiResponse.error('Failed to get recommended doctors: $e');
    }
  }

  // Get home page data
  Future<ApiResponse<Map<String, dynamic>>> getHomePage() async {
    try {
      return await _apiService.getHomePage();
    } catch (e) {
      return ApiResponse.error('Failed to get home page data: $e');
    }
  }

  // Get doctors by specialization
  Future<ApiResponse<List<Doctor>>> getDoctorsBySpecialization(int specializationId) async {
    try {
      return await _apiService.filterDoctors(
        specializationId: specializationId,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get doctors by specialization: $e');
    }
  }

  // Get doctors by city
  Future<ApiResponse<List<Doctor>>> getDoctorsByCity(int cityId) async {
    try {
      return await _apiService.getDoctorsByCity(cityId);
    } catch (e) {
      return ApiResponse.error('Failed to get doctors by city: $e');
    }
  }

  // Get doctors by governorate
  Future<ApiResponse<List<Doctor>>> getDoctorsByGovernrate(int governrateId) async {
    try {
      return await _apiService.getDoctorsByGovernrate(governrateId);
    } catch (e) {
      return ApiResponse.error('Failed to get doctors by governorate: $e');
    }
  }
}
