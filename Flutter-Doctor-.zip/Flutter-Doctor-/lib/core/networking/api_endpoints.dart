class ApiEndpoints {
  // Base URL
  static const String baseUrl = 'https://vcare.integration25.com/api';

  // Auth Module
  static const String register = '/auth/register';
  static const String login = '/auth/login';
  static const String logout = '/auth/logout';

  // Governrate Module
  static const String getAllGovernrates = '/governrate/index';

  // City Module
  static const String getAllCities = '/city/index';
  static const String getCitiesByGovernrate = '/city/show/{id}';

  // Specialization Module
  static const String getAllSpecializations = '/specialization/index';
  static const String showSpecialization = '/specialization/show/{id}';

  // Doctor Module
  static const String getAllDoctors = '/doctor/index';
  static const String showDoctor = '/doctor/show/{id}';
  static const String filterDoctors = '/doctor/doctor-filter';
  static const String searchDoctors = '/doctor/doctor-search';

  // Appointment Module
  static const String getAllAppointments = '/appointment/index';
  static const String storeAppointment = '/appointment/store';

  // User Profile
  static const String getUserProfile = '/user/profile';
  static const String updateProfile = '/user/update';

  // Home Page
  static const String getHomePage = '/home';

  // Helper method to build URLs with parameters
  static String buildUrl(String endpoint, {Map<String, dynamic>? pathParams}) {
    String url = endpoint;
    if (pathParams != null) {
      pathParams.forEach((key, value) {
        url = url.replaceAll('{$key}', value.toString());
      });
    }
    return url;
  }
}
