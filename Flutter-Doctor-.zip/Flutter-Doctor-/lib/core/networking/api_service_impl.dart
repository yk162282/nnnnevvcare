import 'package:dio/dio.dart';
import 'package:doctor_appointment_app/core/networking/api_endpoints.dart';
import 'package:doctor_appointment_app/core/networking/api_service_interface.dart';
import 'package:doctor_appointment_app/core/models/api_response.dart';
import 'package:doctor_appointment_app/core/models/specialization.dart';
import 'package:doctor_appointment_app/core/models/doctor.dart';
import 'package:doctor_appointment_app/core/models/appointment.dart';

class ApiServiceImpl implements ApiServiceInterface {
  late final Dio _dio;
  String? _authToken;

  ApiServiceImpl() {
    _dio = Dio(
      BaseOptions(
        baseUrl: ApiEndpoints.baseUrl,
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
        headers: {
          'Accept': 'application/json',
          // Remove Content-Type to let Dio set it automatically based on data type
        },
      ),
    );

    // Add interceptors for logging and auth
    _dio.interceptors.add(
      LogInterceptor(
        requestBody: true,
        responseBody: true,
        logPrint: (obj) => print(obj),
      ),
    );

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          if (_authToken != null) {
            options.headers['Authorization'] = 'Bearer $_authToken';
          }
          handler.next(options);
        },
        onError: (error, handler) {
          print('API Error: ${error.message}');
          handler.next(error);
        },
      ),
    );
  }

  void setAuthToken(String token) {
    _authToken = token;
  }

  void clearAuthToken() {
    _authToken = null;
  }

  // Auth Module
  @override
  Future<ApiResponse<Map<String, dynamic>>> register({
    required String name,
    required String email,
    required String phone,
    required String gender,
    required String password,
    required String passwordConfirmation,
  }) async {
    try {
      final formData = FormData.fromMap({
        'name': name,
        'email': email,
        'phone': phone,
        'gender': gender,
        'password': password,
        'password_confirmation': passwordConfirmation,
      });

      // Don't set Content-Type header - let Dio set it automatically for FormData
      final response = await _dio.post(ApiEndpoints.register, data: formData);

      if (response.data['status'] == true) {
        // Set token if registration is successful
        final token = response.data['data']['token'];
        if (token != null) {
          setAuthToken(token);
        }
      }

      return ApiResponse.fromJson(
        response.data,
        (data) => data as Map<String, dynamic>,
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Registration failed',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Registration failed: $e');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> login({
    required String email,
    required String password,
  }) async {
    try {
      final formData = FormData.fromMap({'email': email, 'password': password});

      final response = await _dio.post(ApiEndpoints.login, data: formData);

      if (response.data['status'] == true) {
        // Set token if login is successful
        final token = response.data['data']['token'];
        if (token != null) {
          setAuthToken(token);
        }
      }

      return ApiResponse.fromJson(
        response.data,
        (data) => data as Map<String, dynamic>,
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Login failed',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Login failed: $e');
    }
  }

  @override
  Future<ApiResponse<void>> logout() async {
    try {
      await _dio.post(ApiEndpoints.logout);
      clearAuthToken();
      return ApiResponse.success(null, message: 'Logged out successfully');
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Logout failed',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Logout failed: $e');
    }
  }

  // Governrate Module
  @override
  Future<ApiResponse<List<Map<String, dynamic>>>> getAllGovernrates() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllGovernrates);
      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).cast<Map<String, dynamic>>(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get governrates',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get governrates: $e');
    }
  }

  // City Module
  @override
  Future<ApiResponse<List<Map<String, dynamic>>>> getAllCities() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllCities);
      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).cast<Map<String, dynamic>>(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get cities',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get cities: $e');
    }
  }

  @override
  Future<ApiResponse<List<Map<String, dynamic>>>> getCitiesByGovernrate(
    int governrateId,
  ) async {
    try {
      final url = ApiEndpoints.buildUrl(
        ApiEndpoints.getCitiesByGovernrate,
        pathParams: {'id': governrateId},
      );
      final response = await _dio.get(url);
      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).cast<Map<String, dynamic>>(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get cities',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get cities: $e');
    }
  }

  // Specialization Module
  @override
  Future<ApiResponse<List<Specialization>>> getAllSpecializations() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllSpecializations);
      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List)
            .map((json) => Specialization.fromJson(json))
            .toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get specializations',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get specializations: $e');
    }
  }

  @override
  Future<ApiResponse<Specialization>> showSpecialization(int id) async {
    try {
      final url = ApiEndpoints.buildUrl(
        ApiEndpoints.showSpecialization,
        pathParams: {'id': id},
      );
      final response = await _dio.get(url);
      return ApiResponse.fromJson(
        response.data,
        (data) => Specialization.fromJson(data),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get specialization',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get specialization: $e');
    }
  }

  // Doctor Module
  @override
  Future<ApiResponse<List<Doctor>>> getAllDoctors() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllDoctors);
      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).map((json) => Doctor.fromJson(json)).toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get doctors',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get doctors: $e');
    }
  }

  @override
  Future<ApiResponse<Doctor>> showDoctor(int id) async {
    try {
      final url = ApiEndpoints.buildUrl(
        ApiEndpoints.showDoctor,
        pathParams: {'id': id},
      );
      final response = await _dio.get(url);
      return ApiResponse.fromJson(
        response.data,
        (data) => Doctor.fromJson(data),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get doctor',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get doctor: $e');
    }
  }

  @override
  Future<ApiResponse<List<Doctor>>> filterDoctors({
    int? cityId,
    int? specializationId,
    double? minRating,
    bool? availableToday,
  }) async {
    try {
      final queryParams = <String, dynamic>{};
      if (cityId != null) queryParams['city'] = cityId;
      if (specializationId != null) {
        queryParams['specialization'] = specializationId;
      }
      if (minRating != null) queryParams['rating'] = minRating;
      if (availableToday == true) queryParams['available_today'] = 1;

      final response = await _dio.get(
        ApiEndpoints.filterDoctors,
        queryParameters: queryParams,
      );

      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).map((json) => Doctor.fromJson(json)).toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to filter doctors',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to filter doctors: $e');
    }
  }

  @override
  Future<ApiResponse<List<Doctor>>> searchDoctors(String query) async {
    try {
      final response = await _dio.get(
        ApiEndpoints.searchDoctors,
        queryParameters: {'name': query},
      );

      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).map((json) => Doctor.fromJson(json)).toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to search doctors',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to search doctors: $e');
    }
  }

  // Advanced Doctor Features
  @override
  Future<ApiResponse<List<Doctor>>> getDoctorsByCity(int cityId) async {
    try {
      final response = await _dio.get(
        ApiEndpoints.filterDoctors,
        queryParameters: {'city': cityId},
      );

      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).map((json) => Doctor.fromJson(json)).toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get doctors by city',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get doctors by city: $e');
    }
  }

  @override
  Future<ApiResponse<List<Doctor>>> getDoctorsBySpecialization(
    int specializationId,
  ) async {
    try {
      final response = await _dio.get(
        ApiEndpoints.filterDoctors,
        queryParameters: {'specialization': specializationId},
      );

      return ApiResponse.fromJson(
        response.data,
        (data) => (data as List).map((json) => Doctor.fromJson(json)).toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ??
            'Failed to get doctors by specialization',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get doctors by specialization: $e');
    }
  }

  @override
  Future<ApiResponse<List<Doctor>>> getDoctorsByGovernrate(
    int governrateId,
  ) async {
    try {
      // First get cities in the governorate, then get doctors in those cities
      final citiesResponse = await _dio.get(
        ApiEndpoints.buildUrl(
          ApiEndpoints.getCitiesByGovernrate,
          pathParams: {'id': governrateId},
        ),
      );

      if (citiesResponse.data['status'] == true &&
          citiesResponse.data['data'] != null) {
        final cities = citiesResponse.data['data'] as List;
        final allDoctors = <Doctor>[];

        // Get doctors from each city
        for (final city in cities) {
          final cityId = city['id'];
          final doctorsResponse = await _dio.get(
            ApiEndpoints.filterDoctors,
            queryParameters: {'city': cityId},
          );

          if (doctorsResponse.data['status'] == true &&
              doctorsResponse.data['data'] != null) {
            final doctors = (doctorsResponse.data['data'] as List)
                .map((json) => Doctor.fromJson(json))
                .toList();
            allDoctors.addAll(doctors);
          }
        }

        return ApiResponse.success(
          allDoctors,
          message: 'Doctors loaded successfully',
        );
      }

      return ApiResponse.error('Failed to get cities for governorate');
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get doctors by governorate',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get doctors by governorate: $e');
    }
  }

  // Appointment Module
  @override
  Future<ApiResponse<List<Appointment>>> getAllAppointments() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllAppointments);
      return ApiResponse.fromJson(
        response.data,
        (data) =>
            (data as List).map((json) => Appointment.fromJson(json)).toList(),
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get appointments',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get appointments: $e');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> storeAppointment({
    required int doctorId,
    required DateTime startTime,
    String? notes,
  }) async {
    try {
      final formData = FormData.fromMap({
        'doctor_id': doctorId,
        'start_time': startTime.toIso8601String(),
        if (notes != null) 'notes': notes,
      });

      final response = await _dio.post(
        ApiEndpoints.storeAppointment,
        data: formData,
      );

      return ApiResponse.fromJson(
        response.data,
        (data) => data as Map<String, dynamic>,
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to create appointment',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to create appointment: $e');
    }
  }

  // Advanced Appointment Features
  @override
  Future<ApiResponse<List<Appointment>>> getUpcomingAppointments() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllAppointments);

      if (response.data['status'] == true && response.data['data'] != null) {
        final allAppointments = (response.data['data'] as List)
            .map((json) => Appointment.fromJson(json))
            .toList();

        // Filter upcoming appointments (today and future)
        final now = DateTime.now();
        final upcoming = allAppointments.where((appointment) {
          return appointment.startTime.isAfter(now);
        }).toList();

        return ApiResponse.success(
          upcoming,
          message: 'Upcoming appointments loaded',
        );
      }

      return ApiResponse.error('Failed to load appointments');
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to load upcoming appointments',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to load upcoming appointments: $e');
    }
  }

  @override
  Future<ApiResponse<List<Appointment>>> getPastAppointments() async {
    try {
      final response = await _dio.get(ApiEndpoints.getAllAppointments);

      if (response.data['status'] == true && response.data['data'] != null) {
        final allAppointments = (response.data['data'] as List)
            .map((json) => Appointment.fromJson(json))
            .toList();

        // Filter past appointments
        final now = DateTime.now();
        final past = allAppointments.where((appointment) {
          return appointment.startTime.isBefore(now);
        }).toList();

        return ApiResponse.success(past, message: 'Past appointments loaded');
      }

      return ApiResponse.error('Failed to load appointments');
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to load past appointments',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to load past appointments: $e');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> cancelAppointment(
    int appointmentId,
  ) async {
    try {
      // Note: VCARE API doesn't have cancel endpoint, so we'll return a mock response
      // In a real implementation, you'd call the actual cancel endpoint
      return ApiResponse.success({
        'id': appointmentId,
        'status': 'cancelled',
      }, message: 'Appointment cancelled successfully');
    } catch (e) {
      return ApiResponse.error('Failed to cancel appointment: $e');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> rescheduleAppointment({
    required int appointmentId,
    required DateTime newStartTime,
  }) async {
    try {
      // Note: VCARE API doesn't have reschedule endpoint, so we'll return a mock response
      // In a real implementation, you'd call the actual reschedule endpoint
      return ApiResponse.success({
        'id': appointmentId,
        'old_start_time': DateTime.now().toIso8601String(),
        'new_start_time': newStartTime.toIso8601String(),
        'status': 'rescheduled',
      }, message: 'Appointment rescheduled successfully');
    } catch (e) {
      return ApiResponse.error('Failed to reschedule appointment: $e');
    }
  }

  // User Profile
  @override
  Future<ApiResponse<Map<String, dynamic>>> getUserProfile() async {
    try {
      final response = await _dio.get(ApiEndpoints.getUserProfile);
      return ApiResponse.fromJson(
        response.data,
        (data) => data as Map<String, dynamic>,
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get user profile',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get user profile: $e');
    }
  }

  @override
  Future<ApiResponse<Map<String, dynamic>>> updateProfile(
    Map<String, dynamic> data,
  ) async {
    try {
      final formData = FormData.fromMap(data);
      final response = await _dio.post(
        ApiEndpoints.updateProfile,
        data: formData,
      );

      return ApiResponse.fromJson(
        response.data,
        (data) => data as Map<String, dynamic>,
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to update profile',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to update profile: $e');
    }
  }

  // Home Page
  @override
  Future<ApiResponse<Map<String, dynamic>>> getHomePage() async {
    try {
      final response = await _dio.get(ApiEndpoints.getHomePage);
      return ApiResponse.fromJson(
        response.data,
        (data) => data as Map<String, dynamic>,
      );
    } on DioException catch (e) {
      return ApiResponse.error(
        e.response?.data['message'] ?? 'Failed to get home page data',
        code: e.response?.statusCode ?? 500,
      );
    } catch (e) {
      return ApiResponse.error('Failed to get home page data: $e');
    }
  }
}
