import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import '../../features/login/data/models/login_request_body.dart';
import '../../features/login/data/models/login_response.dart';
import '../../features/login/data/models/register_request_body.dart';
import 'api_constants.dart';

part 'api_service.g.dart';

// Error logger interface for retrofit
abstract class ParseErrorLogger {
  void logError(
    Object error,
    StackTrace stackTrace,
    RequestOptions requestOptions,
  );
}

@RestApi(baseUrl: ApiConstants.apiBaseUrl)
abstract class ApiService {
  factory ApiService(
    Dio dio, {
    String? baseUrl,
    ParseErrorLogger? errorLogger,
  }) = _ApiService;

  // Auth Module
  @POST(ApiConstants.register)
  Future<LoginResponse> register(
    @Body() RegisterRequestBody registerRequestBody,
  );

  @POST(ApiConstants.login)
  Future<LoginResponse> login(@Body() LoginRequestBody loginRequestBody);

  @POST(ApiConstants.logout)
  Future<Map<String, dynamic>> logout();

  // User Module
  @GET(ApiConstants.userProfile)
  Future<Map<String, dynamic>> getUserProfile();

  @POST(ApiConstants.updateProfile)
  Future<Map<String, dynamic>> updateProfile(
    @Body() Map<String, dynamic> profileData,
  );

  // Home Module
  @GET(ApiConstants.homePage)
  Future<Map<String, dynamic>> getHomePage();

  // Governrate Module
  @GET(ApiConstants.getAllGovernrates)
  Future<Map<String, dynamic>> getAllGovernrates();

  // City Module
  @GET(ApiConstants.getAllCities)
  Future<Map<String, dynamic>> getAllCities();

  @GET("${ApiConstants.getCitiesByGovernrate}/{governrateId}")
  Future<Map<String, dynamic>> getCitiesByGovernrate(
    @Path('governrateId') int governrateId,
  );

  // Specialization Module
  @GET(ApiConstants.getAllSpecializations)
  Future<Map<String, dynamic>> getAllSpecializations();

  @GET("${ApiConstants.showSpecialization}/{specializationId}")
  Future<Map<String, dynamic>> showSpecialization(
    @Path('specializationId') int specializationId,
  );

  // Doctor Module
  @GET(ApiConstants.getAllDoctors)
  Future<Map<String, dynamic>> getAllDoctors();

  @GET("${ApiConstants.showDoctor}/{doctorId}")
  Future<Map<String, dynamic>> showDoctor(@Path('doctorId') int doctorId);

  @GET(ApiConstants.filterDoctors)
  Future<Map<String, dynamic>> filterDoctors(
    @Query('city') int? city,
    @Query('specialization') int? specialization,
  );

  @GET(ApiConstants.searchDoctors)
  Future<Map<String, dynamic>> searchDoctors(@Query('name') String name);

  // Appointment Module
  @GET(ApiConstants.getAllAppointments)
  Future<Map<String, dynamic>> getAllAppointments();

  @POST(ApiConstants.storeAppointment)
  Future<Map<String, dynamic>> storeAppointment(
    @Body() Map<String, dynamic> appointmentData,
  );
}
