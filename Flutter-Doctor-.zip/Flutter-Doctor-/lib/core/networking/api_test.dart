import 'package:dio/dio.dart';
import 'api_endpoints.dart';

class ApiTest {
  static Future<void> testApiConnection() async {
    final dio = Dio(BaseOptions(
      baseUrl: ApiEndpoints.baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ));

    try {
      print('🔍 Testing API connection to: ${ApiEndpoints.baseUrl}');
      
      // Test basic connectivity
      final response = await dio.get('/');
      print('✅ API is accessible. Status: ${response.statusCode}');
      
      // Test specializations endpoint
      print('🔍 Testing specializations endpoint...');
      final specResponse = await dio.get(ApiEndpoints.getAllSpecializations);
      print('✅ Specializations endpoint working. Status: ${specResponse.statusCode}');
      
      if (specResponse.data != null) {
        print('📊 Response structure: ${specResponse.data.keys.toList()}');
        if (specResponse.data['data'] != null) {
          print('📋 Found ${specResponse.data['data'].length} specializations');
        }
      }
      
    } on DioException catch (e) {
      print('❌ API Error: ${e.message}');
      if (e.response != null) {
        print('📊 Status Code: ${e.response?.statusCode}');
        print('📋 Response: ${e.response?.data}');
      }
    } catch (e) {
      print('❌ Unexpected Error: $e');
    }
  }

  static Future<void> testAuthEndpoints() async {
    final dio = Dio(BaseOptions(
      baseUrl: ApiEndpoints.baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ));

    try {
      print('🔍 Testing auth endpoints...');
      
      // Test register endpoint (without data to see response structure)
      final registerResponse = await dio.post(ApiEndpoints.register);
      print('✅ Register endpoint accessible. Status: ${registerResponse.statusCode}');
      
      // Test login endpoint
      final loginResponse = await dio.post(ApiEndpoints.login);
      print('✅ Login endpoint accessible. Status: ${loginResponse.statusCode}');
      
    } on DioException catch (e) {
      if (e.response?.statusCode == 422) {
        print('✅ Auth endpoints working (422 expected for missing data)');
      } else {
        print('❌ Auth endpoint error: ${e.message}');
      }
    } catch (e) {
      print('❌ Unexpected error in auth test: $e');
    }
  }

  static Future<void> runAllTests() async {
    print('🚀 Starting API Integration Tests...\n');
    
    await testApiConnection();
    print('');
    await testAuthEndpoints();
    
    print('\n✅ API Integration Tests Complete!');
  }
}
