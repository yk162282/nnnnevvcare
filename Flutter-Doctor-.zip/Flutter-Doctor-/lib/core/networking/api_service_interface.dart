import '../models/api_response.dart';
import '../models/specialization.dart';
import '../models/doctor.dart';
import '../models/appointment.dart';

abstract class ApiServiceInterface {
  // Auth Module
  Future<ApiResponse<Map<String, dynamic>>> register({
    required String name,
    required String email,
    required String phone,
    required String gender,
    required String password,
    required String passwordConfirmation,
  });

  Future<ApiResponse<Map<String, dynamic>>> login({
    required String email,
    required String password,
  });

  Future<ApiResponse<void>> logout();

  // Governrate Module
  Future<ApiResponse<List<Map<String, dynamic>>>> getAllGovernrates();

  // City Module
  Future<ApiResponse<List<Map<String, dynamic>>>> getAllCities();
  Future<ApiResponse<List<Map<String, dynamic>>>> getCitiesByGovernrate(int governrateId);

  // Specialization Module
  Future<ApiResponse<List<Specialization>>> getAllSpecializations();
  Future<ApiResponse<Specialization>> showSpecialization(int id);

  // Doctor Module
  Future<ApiResponse<List<Doctor>>> getAllDoctors();
  Future<ApiResponse<Doctor>> showDoctor(int id);
  Future<ApiResponse<List<Doctor>>> filterDoctors({
    int? cityId,
    int? specializationId,
    double? minRating,
    bool? availableToday,
  });
  Future<ApiResponse<List<Doctor>>> searchDoctors(String query);
  
  // Advanced Doctor Features
  Future<ApiResponse<List<Doctor>>> getDoctorsByCity(int cityId);
  Future<ApiResponse<List<Doctor>>> getDoctorsBySpecialization(int specializationId);
  Future<ApiResponse<List<Doctor>>> getDoctorsByGovernrate(int governrateId);

  // Appointment Module
  Future<ApiResponse<List<Appointment>>> getAllAppointments();
  Future<ApiResponse<Map<String, dynamic>>> storeAppointment({
    required int doctorId,
    required DateTime startTime,
    String? notes,
  });
  
  // Advanced Appointment Features
  Future<ApiResponse<List<Appointment>>> getUpcomingAppointments();
  Future<ApiResponse<List<Appointment>>> getPastAppointments();
  Future<ApiResponse<Map<String, dynamic>>> cancelAppointment(int appointmentId);
  Future<ApiResponse<Map<String, dynamic>>> rescheduleAppointment({
    required int appointmentId,
    required DateTime newStartTime,
  });

  // User Profile
  Future<ApiResponse<Map<String, dynamic>>> getUserProfile();
  Future<ApiResponse<Map<String, dynamic>>> updateProfile(Map<String, dynamic> data);

  // Home Page
  Future<ApiResponse<Map<String, dynamic>>> getHomePage();
}
