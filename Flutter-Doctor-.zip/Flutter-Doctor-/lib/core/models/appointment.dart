class Appointment {
  final int id;
  final int doctorId;
  final String doctorName;
  final String? doctorImage;
  final String? doctorSpecialization;
  final DateTime startTime;
  final String? notes;
  final String status;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Appointment({
    required this.id,
    required this.doctorId,
    required this.doctorName,
    this.doctorImage,
    this.doctorSpecialization,
    required this.startTime,
    this.notes,
    required this.status,
    this.createdAt,
    this.updatedAt,
  });

  factory Appointment.fromJson(Map<String, dynamic> json) {
    return Appointment(
      id: json['id'] ?? 0,
      doctorId: json['doctor_id'] ?? 0,
      doctorName: json['doctor']?['name'] ?? json['doctor_name'] ?? '',
      doctorImage: json['doctor']?['image'] ?? json['doctor_image'],
      doctorSpecialization: json['doctor']?['specialization']?['name'] ?? json['doctor_specialization'],
      startTime: DateTime.parse(json['start_time']),
      notes: json['notes'],
      status: json['status'] ?? 'pending',
      createdAt: json['created_at'] != null 
          ? DateTime.parse(json['created_at']) 
          : null,
      updatedAt: json['updated_at'] != null 
          ? DateTime.parse(json['updated_at']) 
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'doctor_id': doctorId,
      'doctor_name': doctorName,
      'doctor_image': doctorImage,
      'doctor_specialization': doctorSpecialization,
      'start_time': startTime.toIso8601String(),
      'notes': notes,
      'status': status,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  @override
  String toString() {
    return 'Appointment(id: $id, doctor: $doctorName, time: $startTime, status: $status)';
  }
}
