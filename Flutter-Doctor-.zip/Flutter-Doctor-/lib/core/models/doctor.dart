import 'specialization.dart';

class Doctor {
  final int id;
  final String name;
  final String? email;
  final String? phone;
  final String? image;
  final String? bio;
  final String? experience;
  final String? education;
  final String? languages;
  final String? address;
  final double? rating;
  final int? reviewCount;
  final bool isAvailable;
  final Specialization? specialization;
  final String? city;
  final String? governrate;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Doctor({
    required this.id,
    required this.name,
    this.email,
    this.phone,
    this.image,
    this.bio,
    this.experience,
    this.education,
    this.languages,
    this.address,
    this.rating,
    this.reviewCount,
    this.isAvailable = true,
    this.specialization,
    this.city,
    this.governrate,
    this.createdAt,
    this.updatedAt,
  });

  factory Doctor.fromJson(Map<String, dynamic> json) {
    final doctor = Doctor(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      email: json['email'],
      phone: json['phone'],
      image: json['image'],
      bio: json['bio'],
      experience: json['experience'],
      education: json['education'],
      languages: json['languages'],
      address: json['address'],
      rating: json['rating'] != null
          ? double.parse(json['rating'].toString())
          : null,
      reviewCount: json['review_count'] ?? json['reviews_count'],
      isAvailable: json['is_available'] ?? true,
      specialization: json['specialization'] != null
          ? Specialization.fromJson(json['specialization'])
          : null,
      city: json['city']?['name'] ?? json['city_name'],
      governrate: json['governrate']?['name'] ?? json['governrate_name'],
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
    );

    return doctor;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'image': image,
      'bio': bio,
      'experience': experience,
      'education': education,
      'languages': languages,
      'address': address,
      'rating': rating,
      'review_count': reviewCount,
      'is_available': isAvailable,
      'specialization': specialization?.toJson(),
      'city': city,
      'governrate': governrate,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  @override
  String toString() {
    return 'Doctor(id: $id, name: $name, specialization: ${specialization?.name})';
  }
}
