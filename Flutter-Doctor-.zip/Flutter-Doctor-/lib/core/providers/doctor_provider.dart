import 'package:flutter/foundation.dart';
import '../models/doctor.dart';
import '../models/specialization.dart';
import '../repositories/doctor_repository.dart';

class DoctorProvider extends ChangeNotifier {
  final DoctorRepository _repository;

  DoctorProvider(this._repository);

  // State variables
  List<Doctor> _doctors = [];
  List<Doctor> _filteredDoctors = [];
  List<Doctor> _recommendedDoctors = [];
  List<Specialization> _specializations = [];

  Doctor? _selectedDoctor;
  Specialization? _selectedSpecialization;

  bool _isLoading = false;
  String? _errorMessage;

  // Getters
  List<Doctor> get doctors => _doctors;
  List<Doctor> get filteredDoctors => _filteredDoctors;
  List<Doctor> get recommendedDoctors => _recommendedDoctors;
  List<Specialization> get specializations => _specializations;

  Doctor? get selectedDoctor => _selectedDoctor;
  Specialization? get selectedSpecialization => _selectedSpecialization;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  // Set selected doctor
  void selectDoctor(Doctor doctor) {
    _selectedDoctor = doctor;
    notifyListeners();
  }

  // Set selected specialization
  void selectSpecialization(Specialization specialization) {
    _selectedSpecialization = specialization;
    notifyListeners();
  }

  // Clear error
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  // Load all doctors
  Future<void> loadAllDoctors() async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.getAllDoctors();

      if (response.isSuccess && response.data != null) {
        _doctors = response.data!;
        _filteredDoctors = _doctors;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to load doctors');
      }
    } catch (e) {
      _setError('Failed to load doctors: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Load specializations
  Future<void> loadSpecializations() async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.getAllSpecializations();

      if (response.isSuccess && response.data != null) {
        _specializations = response.data!;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to load specializations');
      }
    } catch (e) {
      _setError('Failed to load specializations: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Search doctors
  Future<void> searchDoctors(String query) async {
    if (query.trim().isEmpty) {
      _filteredDoctors = _doctors;
      notifyListeners();
      return;
    }

    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.searchDoctors(query);

      if (response.isSuccess && response.data != null) {
        _filteredDoctors = response.data!;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to search doctors');
      }
    } catch (e) {
      _setError('Failed to search doctors: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Filter doctors
  Future<void> filterDoctors({
    int? cityId,
    int? specializationId,
    double? minRating,
    bool? availableToday,
  }) async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.filterDoctors(
        cityId: cityId,
        specializationId: specializationId,
        minRating: minRating,
        availableToday: availableToday,
      );

      if (response.isSuccess && response.data != null) {
        _filteredDoctors = response.data!;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to filter doctors');
      }
    } catch (e) {
      _setError('Failed to filter doctors: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Load doctor details
  Future<void> loadDoctorDetails(int doctorId) async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.getDoctorById(doctorId);

      if (response.isSuccess && response.data != null) {
        _selectedDoctor = response.data!;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to load doctor details');
      }
    } catch (e) {
      _setError('Failed to load doctor details: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Load doctors by specialization
  Future<void> loadDoctorsBySpecialization(int specializationId) async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.getDoctorsBySpecialization(
        specializationId,
      );

      if (response.isSuccess && response.data != null) {
        _filteredDoctors = response.data!;
        notifyListeners();
      } else {
        _setError(
          response.message ?? 'Failed to load doctors by specialization',
        );
      }
    } catch (e) {
      _setError('Failed to load doctors by specialization: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Advanced filtering with multiple criteria
  Future<void> advancedFilterDoctors({
    int? cityId,
    int? specializationId,
    int? governrateId,
    double? minRating,
    bool? availableToday,
    String? searchQuery,
  }) async {
    _setLoading(true);
    _clearError();

    try {
      List<Doctor> filteredResults = [];

      // Start with all doctors
      if (_doctors.isEmpty) {
        await loadAllDoctors();
      }

      filteredResults = List<Doctor>.from(_doctors);

      // Apply city filter
      if (cityId != null) {
        final cityResponse = await _repository.getDoctorsByCity(cityId);
        if (cityResponse.isSuccess && cityResponse.data != null) {
          final cityDoctors = cityResponse.data!;
          filteredResults = filteredResults.where((doctor) {
            return cityDoctors.any((cityDoctor) => cityDoctor.id == doctor.id);
          }).toList();
        }
      }

      // Apply specialization filter
      if (specializationId != null) {
        final specResponse = await _repository.getDoctorsBySpecialization(
          specializationId,
        );
        if (specResponse.isSuccess && specResponse.data != null) {
          final specDoctors = specResponse.data!;
          filteredResults = filteredResults.where((doctor) {
            return specDoctors.any((specDoctor) => specDoctor.id == doctor.id);
          }).toList();
        }
      }

      // Apply governorate filter
      if (governrateId != null) {
        final govResponse = await _repository.getDoctorsByGovernrate(
          governrateId,
        );
        if (govResponse.isSuccess && govResponse.data != null) {
          final govDoctors = govResponse.data!;
          filteredResults = filteredResults.where((doctor) {
            return govDoctors.any((govDoctor) => govDoctor.id == doctor.id);
          }).toList();
        }
      }

      // Apply rating filter (if available)
      if (minRating != null) {
        filteredResults = filteredResults.where((doctor) {
          return (doctor.rating ?? 0) >= minRating;
        }).toList();
      }

      // Apply availability filter
      if (availableToday == true) {
        // Since API doesn't have availability, we'll simulate it
        filteredResults = filteredResults.where((doctor) {
          return doctor.isAvailable;
        }).toList();
      }

      // Apply search query
      if (searchQuery != null && searchQuery.trim().isNotEmpty) {
        final searchResponse = await _repository.searchDoctors(searchQuery);
        if (searchResponse.isSuccess && searchResponse.data != null) {
          final searchDoctors = searchResponse.data!;
          filteredResults = filteredResults.where((doctor) {
            return searchDoctors.any(
              (searchDoctor) => searchDoctor.id == doctor.id,
            );
          }).toList();
        }
      }

      _filteredDoctors = filteredResults;
      notifyListeners();
    } catch (e) {
      _setError('Failed to filter doctors: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Load doctors by city
  Future<void> loadDoctorsByCity(int cityId) async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.getDoctorsByCity(cityId);

      if (response.isSuccess && response.data != null) {
        _filteredDoctors = response.data!;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to load doctors by city');
      }
    } catch (e) {
      _setError('Failed to load doctors by city: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Load doctors by governorate
  Future<void> loadDoctorsByGovernrate(int governrateId) async {
    _setLoading(true);
    _clearError();

    try {
      final response = await _repository.getDoctorsByGovernrate(governrateId);

      if (response.isSuccess && response.data != null) {
        _filteredDoctors = response.data!;
        notifyListeners();
      } else {
        _setError(response.message ?? 'Failed to load doctors by governorate');
      }
    } catch (e) {
      _setError('Failed to load doctors by governorate: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Clear all filters and show all doctors
  void clearFilters() {
    _filteredDoctors = _doctors;
    notifyListeners();
  }

  // Get filtered doctors count
  int get filteredDoctorsCount => _filteredDoctors.length;

  // Get doctors by rating range
  List<Doctor> getDoctorsByRatingRange(double minRating, double maxRating) {
    return _doctors.where((doctor) {
      final rating = doctor.rating ?? 0;
      return rating >= minRating && rating <= maxRating;
    }).toList();
  }

  // Load home page data
  Future<void> loadHomePageData() async {
    _setLoading(true);
    _clearError();

    try {
      // Load specializations, all doctors, and recommended doctors
      await Future.wait([
        loadSpecializations(),
        loadAllDoctors(),
        loadRecommendedDoctors(),
      ]);
    } catch (e) {
      _setError('Failed to load home page data: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Load recommended doctors
  Future<void> loadRecommendedDoctors() async {
    try {
      final response = await _repository.getRecommendedDoctors();

      if (response.isSuccess && response.data != null) {
        _recommendedDoctors = response.data!;
        notifyListeners();
      } else {
        // If API fails, try to get top rated doctors from existing data
        if (_doctors.isNotEmpty) {
          final sortedDoctors = List<Doctor>.from(_doctors);
          sortedDoctors.sort(
            (a, b) => (b.rating ?? 0).compareTo(a.rating ?? 0),
          );
          _recommendedDoctors = sortedDoctors.take(6).toList();
          notifyListeners();
        }
      }
    } catch (e) {
      // Fallback to existing doctors if available
      if (_doctors.isNotEmpty) {
        final sortedDoctors = List<Doctor>.from(_doctors);
        sortedDoctors.sort((a, b) => (b.rating ?? 0).compareTo(a.rating ?? 0));
        _recommendedDoctors = sortedDoctors.take(6).toList();
        notifyListeners();
      }
    }
  }

  // Refresh all data
  Future<void> refresh() async {
    await loadHomePageData();
  }

  // Private helper methods
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
  }
}
