import 'package:flutter/material.dart';
import '../../features/login/data/models/user_profile.dart';

class UserProvider extends ChangeNotifier {
  UserProfile? _currentUser;
  bool _isLoggedIn = false;

  UserProfile? get currentUser => _currentUser;
  bool get isLoggedIn => _isLoggedIn;

  void setUser(UserProfile user) {
    _currentUser = user;
    _isLoggedIn = true;
    notifyListeners();
  }

  void updateUser(UserProfile updatedUser) {
    _currentUser = updatedUser;
    notifyListeners();
  }

  void logout() {
    _currentUser = null;
    _isLoggedIn = false;
    notifyListeners();
  }

  void clearUser() {
    _currentUser = null;
    _isLoggedIn = false;
    notifyListeners();
  }
}
