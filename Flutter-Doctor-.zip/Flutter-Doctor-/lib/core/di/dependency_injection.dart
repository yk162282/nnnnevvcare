import 'package:get_it/get_it.dart';
import 'package:provider/provider.dart';
import '../networking/api_service_interface.dart';
import '../networking/api_service_impl.dart';
import '../repositories/doctor_repository.dart';
import '../providers/doctor_provider.dart';

final GetIt getIt = GetIt.instance;

class DependencyInjection {
  static void setup() {
    // Register API Service
    getIt.registerLazySingleton<ApiServiceInterface>(
      () => ApiServiceImpl(),
    );

    // Register Repositories
    getIt.registerLazySingleton<DoctorRepository>(
      () => DoctorRepository(getIt<ApiServiceInterface>()),
    );

    // Register Providers
    getIt.registerLazySingleton<DoctorProvider>(
      () => DoctorProvider(getIt<DoctorRepository>()),
    );
  }

  static List<ChangeNotifierProvider> getProviders() {
    return [
      ChangeNotifierProvider<DoctorProvider>(
        create: (context) => getIt<DoctorProvider>(),
      ),
    ];
  }

  static void dispose() {
    getIt.reset();
  }
}
