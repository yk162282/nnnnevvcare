import 'package:doctor_appointment_app/core/routing/routes.dart';
import 'package:flutter/material.dart';

// Auth & Onboarding Screens
import '../../features/login/ui/login_screen.dart';
import '../../features/onboarding/onboarding_screen.dart';
import '../../features/signup/signup_screen.dart';
import '../../features/auth/forgot_password_screen.dart';
import '../../features/auth/otp_verification_screen.dart';
import '../../features/auth/create_new_password_screen.dart';
import '../../features/auth/fill_profile_screen.dart';
import '../../features/auth/face_id_screen.dart';

// Main App Screens
import '../../features/home/ui/home_screen.dart';
import '../../features/profile/ui/screens/profile_screen.dart';
import '../../features/profile/ui/screens/personal_info_screen.dart';
import '../../features/doctors/ui/screens/doctors_screen.dart';
import '../../features/doctors/ui/screens/doctor_detail_screen.dart';
import '../../features/appointments/ui/screens/appointments_screen.dart';
import '../../features/appointments/ui/screens/booking_appointment_screen.dart';

// Test Screens
import '../../features/test/api_test_screen.dart';

class AppRouter {
  Route generateRoute(RouteSettings settings) {
    //this arguments to be passed in any screen like this ( arguments as ClassName )

    switch (settings.name) {
      // Auth & Onboarding Routes
      case Routes.onBoardingScreen:
        return MaterialPageRoute(builder: (_) => const OnboardingScreen());
      case Routes.loginScreen:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case Routes.signupScreen:
        return MaterialPageRoute(builder: (_) => const SignupScreen());
      case Routes.forgotPasswordScreen:
        return MaterialPageRoute(builder: (_) => const ForgotPasswordScreen());
      case Routes.otpVerificationScreen:
        return MaterialPageRoute(builder: (_) => const OtpVerificationScreen());
      case Routes.createNewPasswordScreen:
        return MaterialPageRoute(
          builder: (_) => const CreateNewPasswordScreen(),
        );
      case Routes.fillProfileScreen:
        final userData = settings.arguments as Map<String, String>?;
        return MaterialPageRoute(
          builder: (_) => FillProfileScreen(userData: userData),
        );
      case Routes.faceIdScreen:
        return MaterialPageRoute(builder: (_) => const FaceIdScreen());

      // Main App Routes
      case Routes.homeScreen:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case Routes.profileScreen:
        return MaterialPageRoute(builder: (_) => const ProfileScreen());
      case Routes.personalInfoScreen:
        return MaterialPageRoute(builder: (_) => const PersonalInfoScreen());
      case Routes.doctorsScreen:
        return MaterialPageRoute(builder: (_) => const DoctorsScreen());
      case Routes.doctorDetailScreen:
        final doctor = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => DoctorDetailScreen(doctor: doctor ?? {}),
        );
      case Routes.appointmentsScreen:
        return MaterialPageRoute(builder: (_) => const AppointmentsScreen());
      case Routes.bookingScreen:
        final doctor = settings.arguments as Map<String, dynamic>?;
        return MaterialPageRoute(
          builder: (_) => BookingAppointmentScreen(doctor: doctor ?? {}),
        );
      case Routes.apiTestScreen:
        return MaterialPageRoute(builder: (_) => const ApiTestScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}
