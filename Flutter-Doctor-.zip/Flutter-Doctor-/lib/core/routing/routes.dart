class Routes {
  // Auth & Onboarding
  static const String onBoardingScreen = '/onBoardingScreen';
  static const String loginScreen = '/loginScreen';
  static const String signupScreen = '/signupScreen';
  static const String forgotPasswordScreen = '/forgotPasswordScreen';
  static const String otpVerificationScreen = '/otpVerificationScreen';
  static const String createNewPasswordScreen = '/createNewPasswordScreen';
  static const String fillProfileScreen = '/fillProfileScreen';
  static const String faceIdScreen = '/faceIdScreen';

  // Main App
  static const String homeScreen = '/homeScreen';
  static const String profileScreen = '/profileScreen';
  static const String personalInfoScreen = '/personalInfoScreen';
  static const String doctorsScreen = '/doctorsScreen';
  static const String doctorDetailScreen = '/doctorDetailScreen';
  static const String appointmentsScreen = '/appointmentsScreen';
  static const String bookingScreen = '/bookingScreen';

  // Test Routes
  static const String apiTestScreen = '/apiTestScreen';

  // Auth Flow Routes
  static const List<String> authRoutes = [
    onBoardingScreen,
    loginScreen,
    signupScreen,
    forgotPasswordScreen,
    otpVerificationScreen,
    createNewPasswordScreen,
    fillProfileScreen,
    faceIdScreen,
  ];

  // Main App Routes
  static const List<String> mainAppRoutes = [
    homeScreen,
    profileScreen,
    personalInfoScreen,
    doctorsScreen,
    doctorDetailScreen,
    appointmentsScreen,
    bookingScreen,
  ];
}
