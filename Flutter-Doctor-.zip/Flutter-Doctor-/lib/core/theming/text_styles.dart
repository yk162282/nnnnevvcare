import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'colors.dart';
import 'font_weight_helper.dart';

class TextStyles {
  // Private constructor to prevent instantiation
  TextStyles._();

  // Display Styles
  static TextStyle get displayLarge => TextStyle(
    fontSize: 48.sp,
    fontWeight: FontWeightHelper.bold,
    color: ColorsManager.textPrimary,
    height: 1.2,
  );

  static TextStyle get displayMedium => TextStyle(
    fontSize: 36.sp,
    fontWeight: FontWeightHelper.bold,
    color: ColorsManager.textPrimary,
    height: 1.2,
  );

  static TextStyle get displaySmall => TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeightHelper.bold,
    color: ColorsManager.textPrimary,
    height: 1.2,
  );

  // Heading Styles
  static TextStyle get headingLarge => TextStyle(
    fontSize: 32.sp,
    fontWeight: FontWeightHelper.bold,
    color: ColorsManager.textPrimary,
    height: 1.3,
  );

  static TextStyle get headingMedium => TextStyle(
    fontSize: 28.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: ColorsManager.textPrimary,
    height: 1.3,
  );

  static TextStyle get headingSmall => TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: ColorsManager.textPrimary,
    height: 1.3,
  );

  // Title Styles
  static TextStyle get titleLarge => TextStyle(
    fontSize: 20.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  static TextStyle get titleMedium => TextStyle(
    fontSize: 18.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  static TextStyle get titleSmall => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  // Body Styles
  static TextStyle get bodyLarge => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textPrimary,
    height: 1.5,
  );

  static TextStyle get bodyMedium => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textPrimary,
    height: 1.5,
  );

  static TextStyle get bodySmall => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textSecondary,
    height: 1.5,
  );

  // Label Styles
  static TextStyle get labelLarge => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  static TextStyle get labelMedium => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  static TextStyle get labelSmall => TextStyle(
    fontSize: 10.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.textSecondary,
    height: 1.4,
  );

  // Button Styles
  static TextStyle get buttonLarge => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: Colors.white,
    height: 1.2,
  );

  static TextStyle get buttonMedium => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: Colors.white,
    height: 1.2,
  );

  static TextStyle get buttonSmall => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.semiBold,
    color: Colors.white,
    height: 1.2,
  );

  // Link Styles
  static TextStyle get linkLarge => TextStyle(
    fontSize: 16.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.primaryBlue,
    height: 1.4,
    decoration: TextDecoration.underline,
  );

  static TextStyle get linkMedium => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.primaryBlue,
    height: 1.4,
    decoration: TextDecoration.underline,
  );

  static TextStyle get linkSmall => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.primaryBlue,
    height: 1.4,
    decoration: TextDecoration.underline,
  );

  // Caption Styles
  static TextStyle get caption => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textLight,
    height: 1.4,
  );

  // Overline Styles
  static TextStyle get overline => TextStyle(
    fontSize: 10.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.textLight,
    height: 1.4,
    letterSpacing: 1.5,
  );

  // Special Styles for Auth Screens
  static TextStyle get authTitle => TextStyle(
    fontSize: 24.sp,
    fontWeight: FontWeightHelper.bold,
    color: ColorsManager.textPrimary,
    height: 1.2,
  );

  static TextStyle get authSubtitle => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textSecondary,
    height: 1.4,
  );

  static TextStyle get inputLabel => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.medium,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  static TextStyle get inputText => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textPrimary,
    height: 1.4,
  );

  static TextStyle get inputHint => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.textLight,
    height: 1.4,
  );

  static TextStyle get inputError => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeightHelper.regular,
    color: ColorsManager.error,
    height: 1.4,
  );
}
