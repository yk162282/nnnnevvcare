import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'colors.dart';
import '../constants/app_constants.dart';

class ButtonStyles {
  // Private constructor to prevent instantiation
  ButtonStyles._();

  // Primary Button Style
  static ButtonStyle get primary => ElevatedButton.styleFrom(
    backgroundColor: ColorsManager.primaryBlue,
    foregroundColor: Colors.white,
    elevation: 0,
    shadowColor: Colors.transparent,
    minimumSize: Size(double.infinity, AppConstants.primaryButtonHeight.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppConstants.primaryButtonRadius.w),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingL.w,
      vertical: AppConstants.spacingM.h,
    ),
  );

  // Secondary Button Style
  static ButtonStyle get secondary => ElevatedButton.styleFrom(
    backgroundColor: Colors.transparent,
    foregroundColor: ColorsManager.primaryBlue,
    elevation: 0,
    shadowColor: Colors.transparent,
    minimumSize: Size(double.infinity, AppConstants.primaryButtonHeight.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppConstants.primaryButtonRadius.w),
      side: BorderSide(
        color: ColorsManager.primaryBlue,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingL.w,
      vertical: AppConstants.spacingM.h,
    ),
  );

  // Outlined Button Style
  static ButtonStyle get outlined => OutlinedButton.styleFrom(
    foregroundColor: ColorsManager.primaryBlue,
    side: BorderSide(
      color: ColorsManager.inputBorder,
      width: AppConstants.inputFieldBorderWidth,
    ),
    minimumSize: Size(double.infinity, AppConstants.primaryButtonHeight.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppConstants.primaryButtonRadius.w),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingL.w,
      vertical: AppConstants.spacingM.h,
    ),
  );

  // Text Button Style
  static ButtonStyle get text => TextButton.styleFrom(
    foregroundColor: ColorsManager.primaryBlue,
    minimumSize: Size(double.infinity, AppConstants.primaryButtonHeight.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppConstants.primaryButtonRadius.w),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingL.w,
      vertical: AppConstants.spacingM.h,
    ),
  );

  // Small Button Style
  static ButtonStyle get small => ElevatedButton.styleFrom(
    backgroundColor: ColorsManager.primaryBlue,
    foregroundColor: Colors.white,
    elevation: 0,
    shadowColor: Colors.transparent,
    minimumSize: Size(0, 40.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8.w),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingM.w,
      vertical: AppConstants.spacingS.h,
    ),
  );

  // Icon Button Style
  static ButtonStyle get icon => IconButton.styleFrom(
    backgroundColor: ColorsManager.lightBlue,
    foregroundColor: ColorsManager.primaryBlue,
    elevation: 0,
    shadowColor: Colors.transparent,
    minimumSize: Size(44.w, 44.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8.w),
    ),
  );

  // Social Button Style
  static ButtonStyle get social => ElevatedButton.styleFrom(
    backgroundColor: Colors.white,
    foregroundColor: ColorsManager.textPrimary,
    elevation: 1,
    shadowColor: Colors.black.withOpacity(0.1),
    minimumSize: Size(AppConstants.socialButtonSize.w, AppConstants.socialButtonSize.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8.w),
    ),
    padding: EdgeInsets.all(AppConstants.spacingS.w),
  );

  // Disabled Button Style
  static ButtonStyle get disabled => ElevatedButton.styleFrom(
    backgroundColor: ColorsManager.lighterGray,
    foregroundColor: ColorsManager.textLight,
    elevation: 0,
    shadowColor: Colors.transparent,
    minimumSize: Size(double.infinity, AppConstants.primaryButtonHeight.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppConstants.primaryButtonRadius.w),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingL.w,
      vertical: AppConstants.spacingM.h,
    ),
  );

  // Loading Button Style
  static ButtonStyle get loading => ElevatedButton.styleFrom(
    backgroundColor: ColorsManager.primaryBlue.withOpacity(0.7),
    foregroundColor: Colors.white,
    elevation: 0,
    shadowColor: Colors.transparent,
    minimumSize: Size(double.infinity, AppConstants.primaryButtonHeight.h),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppConstants.primaryButtonRadius.w),
    ),
    padding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingL.w,
      vertical: AppConstants.spacingM.h,
    ),
  );
}
