import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'colors.dart';
import 'text_styles.dart';
import '../constants/app_constants.dart';

class InputStyles {
  // Private constructor to prevent instantiation
  InputStyles._();

  // Default Input Decoration
  static InputDecoration get defaultInput => InputDecoration(
    filled: true,
    fillColor: ColorsManager.inputBackground,
    contentPadding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingM.w,
      vertical: AppConstants.spacingM.h,
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.inputFieldRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.inputBorder,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.inputFieldRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.inputBorder,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.inputFieldRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.primaryBlue,
        width: AppConstants.inputFieldBorderWidth + 1,
      ),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.inputFieldRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.error,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.inputFieldRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.error,
        width: AppConstants.inputFieldBorderWidth + 1,
      ),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.inputFieldRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.lighterGray,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    hintStyle: TextStyles.inputHint,
    errorStyle: TextStyles.inputError,
    labelStyle: TextStyles.inputLabel,
    floatingLabelStyle: TextStyles.inputLabel.copyWith(
      color: ColorsManager.primaryBlue,
    ),
  );

  // Input with Label
  static InputDecoration inputWithLabel(String label) => defaultInput.copyWith(
    labelText: label,
    floatingLabelBehavior: FloatingLabelBehavior.auto,
  );

  // Input with Hint
  static InputDecoration inputWithHint(String hint) =>
      defaultInput.copyWith(hintText: hint);

  // Input with Icon
  static InputDecoration inputWithIcon(IconData icon) => defaultInput.copyWith(
    prefixIcon: Icon(
      icon,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
  );

  // Input with Suffix Icon
  static InputDecoration inputWithSuffixIcon(IconData icon) =>
      defaultInput.copyWith(
        suffixIcon: Icon(
          icon,
          color: ColorsManager.textLight,
          size: AppConstants.iconSizeMedium.w,
        ),
      );

  // Input with Prefix and Suffix Icons
  static InputDecoration inputWithIcons({
    IconData? prefixIcon,
    IconData? suffixIcon,
  }) => defaultInput.copyWith(
    prefixIcon: prefixIcon != null
        ? Icon(
            prefixIcon,
            color: ColorsManager.textLight,
            size: AppConstants.iconSizeMedium.w,
          )
        : null,
    suffixIcon: suffixIcon != null
        ? Icon(
            suffixIcon,
            color: ColorsManager.textLight,
            size: AppConstants.iconSizeMedium.w,
          )
        : null,
  );

  // Search Input
  static InputDecoration get searchInput => defaultInput.copyWith(
    hintText: 'Search...',
    prefixIcon: Icon(
      Icons.search,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
    suffixIcon: Icon(
      Icons.clear,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
  );

  // Password Input
  static InputDecoration passwordInput({
    required bool isObscureText,
    required VoidCallback onToggle,
  }) => defaultInput.copyWith(
    hintText: 'Password',
    prefixIcon: Icon(
      Icons.lock_outline,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
    suffixIcon: IconButton(
      icon: Icon(
        isObscureText ? Icons.visibility_off : Icons.visibility,
        color: ColorsManager.textLight,
        size: AppConstants.iconSizeMedium.w,
      ),
      onPressed: onToggle,
    ),
  );

  // Email Input
  static InputDecoration get emailInput => defaultInput.copyWith(
    hintText: 'Email',
    prefixIcon: Icon(
      Icons.email_outlined,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
  );

  // Phone Input
  static InputDecoration get phoneInput => defaultInput.copyWith(
    hintText: 'Phone Number',
    prefixIcon: Icon(
      Icons.phone_outlined,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
  );

  // Name Input
  static InputDecoration get nameInput => defaultInput.copyWith(
    hintText: 'Full Name',
    prefixIcon: Icon(
      Icons.person_outline,
      color: ColorsManager.textLight,
      size: AppConstants.iconSizeMedium.w,
    ),
  );

  // OTP Input
  static InputDecoration get otpInput => defaultInput.copyWith(
    contentPadding: EdgeInsets.symmetric(
      horizontal: AppConstants.spacingS.w,
      vertical: AppConstants.spacingM.h,
    ),
    counterText: '',
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.otpInputRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.inputBorder,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.otpInputRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.inputBorder,
        width: AppConstants.inputFieldBorderWidth,
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppConstants.otpInputRadius.w),
      borderSide: BorderSide(
        color: ColorsManager.primaryBlue,
        width: AppConstants.inputFieldBorderWidth + 1,
      ),
    ),
  );

  // Text Field Style
  static TextStyle get textFieldStyle => TextStyles.inputText;

  // Error Text Style
  static TextStyle get errorTextStyle => TextStyles.inputError;

  // Label Text Style
  static TextStyle get labelTextStyle => TextStyles.inputLabel;
}
