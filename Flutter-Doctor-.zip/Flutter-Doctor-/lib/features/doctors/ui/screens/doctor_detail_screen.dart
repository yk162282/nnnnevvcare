import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';

class DoctorDetailScreen extends StatefulWidget {
  final Map<String, dynamic> doctor;

  const DoctorDetailScreen({
    super.key,
    required this.doctor,
  });

  @override
  State<DoctorDetailScreen> createState() => _DoctorDetailScreenState();
}

class _DoctorDetailScreenState extends State<DoctorDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isFavorite = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: ColorsManager.textPrimary,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                _isFavorite = !_isFavorite;
              });
            },
            icon: Icon(
              _isFavorite ? Icons.favorite : Icons.favorite_border,
              color: _isFavorite ? Colors.red : ColorsManager.textLight,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Profile Section
          _buildProfileSection(),
          
          // Tabs
          _buildTabs(),
          
          // Tab Content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildAboutTab(),
                _buildLocationTab(),
                _buildReviewsTab(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildAppointmentButton(),
    );
  }

  Widget _buildProfileSection() {
    return Container(
      padding: EdgeInsets.all(20.w),
      child: Column(
        children: [
          // Doctor Image
          Container(
            width: 120.w,
            height: 120.w,
            decoration: BoxDecoration(
              color: ColorsManager.lightBlue,
              shape: BoxShape.circle,
              border: Border.all(
                color: ColorsManager.inputBorder,
                width: 3,
              ),
            ),
            child: ClipOval(
              child: widget.doctor['image'] != null
                  ? Image.asset(
                      widget.doctor['image']!,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(
                          Icons.person,
                          size: 60.w,
                          color: ColorsManager.primaryBlue,
                        );
                      },
                    )
                  : Icon(
                      Icons.person,
                      size: 60.w,
                      color: ColorsManager.primaryBlue,
                    ),
            ),
          ),
          SizedBox(height: 16.h),
          
          // Doctor Name
          Text(
            widget.doctor['name'] ?? 'Dr. Unknown',
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 8.h),
          
          // Specialty
          Text(
            widget.doctor['specialty'] ?? 'Specialist',
            style: TextStyle(
              fontSize: 16.sp,
              color: ColorsManager.textSecondary,
            ),
          ),
          SizedBox(height: 8.h),
          
          // Hospital
          Text(
            widget.doctor['hospital'] ?? 'Hospital',
            style: TextStyle(
              fontSize: 14.sp,
              color: ColorsManager.textLight,
            ),
          ),
          SizedBox(height: 16.h),
          
          // Rating
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.star,
                size: 20.w,
                color: Colors.amber,
              ),
              SizedBox(width: 8.w),
              Text(
                '${widget.doctor['rating'] ?? 0.0}',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: ColorsManager.textPrimary,
                ),
              ),
              SizedBox(width: 8.w),
              Text(
                '(${_getReviewCount()} reviews)',
                style: TextStyle(
                  fontSize: 14.sp,
                  color: ColorsManager.textLight,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: ColorsManager.primaryBlue,
          borderRadius: BorderRadius.circular(25.w),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: ColorsManager.textSecondary,
        labelStyle: TextStyle(
          fontSize: 14.sp,
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: TextStyle(
          fontSize: 14.sp,
          fontWeight: FontWeight.w400,
        ),
        tabs: const [
          Tab(text: 'About'),
          Tab(text: 'Location'),
          Tab(text: 'Reviews'),
        ],
      ),
    );
  }

  Widget _buildAboutTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'About Doctor',
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 16.h),
          Text(
            _getDoctorBio(),
            style: TextStyle(
              fontSize: 14.sp,
              color: ColorsManager.textSecondary,
              height: 1.6,
            ),
          ),
          SizedBox(height: 24.h),
          
          // Experience & Education
          _buildInfoCard(
            title: 'Experience',
            content: '15+ years of experience in ${widget.doctor['specialty']}',
            icon: Icons.work,
          ),
          SizedBox(height: 16.h),
          _buildInfoCard(
            title: 'Education',
            content: 'MD from Harvard Medical School',
            icon: Icons.school,
          ),
          SizedBox(height: 16.h),
          _buildInfoCard(
            title: 'Languages',
            content: 'English, Spanish, French',
            icon: Icons.language,
          ),
        ],
      ),
    );
  }

  Widget _buildLocationTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Location',
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 16.h),
          
          // Map Preview
          Container(
            height: 200.h,
            decoration: BoxDecoration(
              color: ColorsManager.lightBlue,
              borderRadius: BorderRadius.circular(12.w),
              border: Border.all(
                color: ColorsManager.inputBorder,
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.location_on,
                    size: 48.w,
                    color: ColorsManager.primaryBlue,
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    'Google Maps Integration',
                    style: TextStyle(
                      fontSize: 16.sp,
                      color: ColorsManager.textSecondary,
                    ),
                  ),
                  Text(
                    'Map preview will be shown here',
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: ColorsManager.textLight,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16.h),
          
          // Address
          _buildInfoCard(
            title: 'Address',
            content: '123 Medical Center Dr, Suite 456\nNew York, NY 10001',
            icon: Icons.location_city,
          ),
        ],
      ),
    );
  }

  Widget _buildReviewsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Patient Reviews',
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 16.h),
          
          // Reviews List
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _getReviews().length,
            itemBuilder: (context, index) {
              final review = _getReviews()[index];
              return _buildReviewCard(review);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required String title,
    required String content,
    required IconData icon,
  }) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40.w,
            height: 40.w,
            decoration: BoxDecoration(
              color: ColorsManager.lightBlue,
              borderRadius: BorderRadius.circular(8.w),
            ),
            child: Icon(
              icon,
              size: 20.w,
              color: ColorsManager.primaryBlue,
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: ColorsManager.textPrimary,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  content,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: ColorsManager.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewCard(Map<String, dynamic> review) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20.w,
                backgroundColor: ColorsManager.lightBlue,
                child: Text(
                  review['patientName'][0].toUpperCase(),
                  style: TextStyle(
                    color: ColorsManager.primaryBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      review['patientName'],
                      style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                        color: ColorsManager.textPrimary,
                      ),
                    ),
                    Row(
                      children: List.generate(5, (index) {
                        return Icon(
                          index < review['rating'] ? Icons.star : Icons.star_border,
                          size: 16.w,
                          color: index < review['rating'] ? Colors.amber : ColorsManager.textLight,
                        );
                      }),
                    ),
                  ],
                ),
              ),
              Text(
                review['date'],
                style: TextStyle(
                  fontSize: 12.sp,
                  color: ColorsManager.textLight,
                ),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          Text(
            review['comment'],
            style: TextStyle(
              fontSize: 14.sp,
              color: ColorsManager.textSecondary,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppointmentButton() {
    return Container(
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SizedBox(
        width: double.infinity,
        height: 55.h,
        child: ElevatedButton(
          onPressed: () {
            // TODO: Navigate to booking appointment screen
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: ColorsManager.primaryBlue,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(27.5.w),
            ),
          ),
          child: Text(
            'Make Appointment',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  String _getDoctorBio() {
    return 'Dr. ${widget.doctor['name']?.split(' ').last ?? 'Unknown'} is a highly experienced ${widget.doctor['specialty']?.toLowerCase() ?? 'specialist'} with over 15 years of practice. They specialize in providing comprehensive care and treatment for patients with various medical conditions. Dr. ${widget.doctor['name']?.split(' ').last ?? 'Unknown'} is known for their compassionate approach and commitment to patient well-being.';
  }

  int _getReviewCount() {
    return 127; // Mock data
  }

  List<Map<String, dynamic>> _getReviews() {
    return [
      {
        'patientName': 'Sarah Johnson',
        'rating': 5,
        'comment': 'Excellent doctor! Very professional and caring. Highly recommend.',
        'date': '2 days ago',
      },
      {
        'patientName': 'Michael Chen',
        'rating': 5,
        'comment': 'Dr. ${widget.doctor['name']?.split(' ').last ?? 'Unknown'} is amazing. Very knowledgeable and patient.',
        'date': '1 week ago',
      },
      {
        'patientName': 'Emily Davis',
        'rating': 4,
        'comment': 'Great experience overall. The doctor was thorough and explained everything clearly.',
        'date': '2 weeks ago',
      },
    ];
  }
}
