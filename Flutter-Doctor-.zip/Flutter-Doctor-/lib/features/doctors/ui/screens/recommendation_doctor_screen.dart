import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';
import 'package:doctor_appointment_app/features/home/widgets/doctor_card.dart';

class RecommendationDoctorScreen extends StatefulWidget {
  const RecommendationDoctorScreen({super.key});

  @override
  State<RecommendationDoctorScreen> createState() =>
      _RecommendationDoctorScreenState();
}

class _RecommendationDoctorScreenState
    extends State<RecommendationDoctorScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          'Recommendation Doctor',
          style: TextStyle(
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
            color: ColorsManager.textPrimary,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: ColorsManager.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // TODO: Show filter/sort options
            },
            icon: Icon(Icons.filter_list, color: ColorsManager.textPrimary),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView.builder(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
          itemCount: _recommendedDoctors.length,
          itemBuilder: (context, index) {
            final doctor = _recommendedDoctors[index];
            return DoctorCard(
              doctor: doctor,
              onTap: () {
                // TODO: Navigate to doctor detail screen
              },
            );
          },
        ),
      ),
    );
  }

  // Mock data for recommended doctors
  final List<Map<String, dynamic>> _recommendedDoctors = [
    {
      'name': 'Dr. Sarah Johnson',
      'specialty': 'Cardiologist',
      'hospital': 'City Heart Hospital',
      'rating': 4.8,
      'image': 'assets/images/doctors/doctor1.png',
    },
    {
      'name': 'Dr. Michael Chen',
      'specialty': 'Neurologist',
      'hospital': 'Neuro Care Center',
      'rating': 4.9,
      'image': 'assets/images/doctors/doctor2.png',
    },
    {
      'name': 'Dr. Emily Davis',
      'specialty': 'Pediatrician',
      'hospital': 'Children\'s Medical Center',
      'rating': 4.7,
      'image': 'assets/images/doctors/doctor3.png',
    },
    {
      'name': 'Dr. Robert Wilson',
      'specialty': 'Orthopedic',
      'hospital': 'Bone & Joint Institute',
      'rating': 4.6,
      'image': 'assets/images/doctors/doctor4.png',
    },
    {
      'name': 'Dr. Lisa Anderson',
      'specialty': 'Dermatologist',
      'hospital': 'Skin Care Clinic',
      'rating': 4.8,
      'image': 'assets/images/doctors/doctor5.png',
    },
    {
      'name': 'Dr. James Brown',
      'specialty': 'ENT Specialist',
      'hospital': 'Ear Nose Throat Center',
      'rating': 4.7,
      'image': 'assets/images/doctors/doctor6.png',
    },
  ];
}
