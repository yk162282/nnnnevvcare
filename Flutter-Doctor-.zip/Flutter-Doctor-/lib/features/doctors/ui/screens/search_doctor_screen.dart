import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';
import 'package:doctor_appointment_app/features/home/widgets/doctor_card.dart';

class SearchDoctorScreen extends StatefulWidget {
  const SearchDoctorScreen({super.key});

  @override
  State<SearchDoctorScreen> createState() => _SearchDoctorScreenState();
}

class _SearchDoctorScreenState extends State<SearchDoctorScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _showMap = false;
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: ColorsManager.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Search Doctor',
          style: TextStyle(
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
            color: ColorsManager.textPrimary,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search Bar
            Padding(
              padding: EdgeInsets.all(16.w),
              child: Container(
                height: 50.h,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25.w),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Search doctor or specialty',
                    hintStyle: TextStyle(
                      color: ColorsManager.textLight,
                      fontSize: 14.sp,
                    ),
                    prefixIcon: Icon(
                      Icons.search,
                      size: 24.w,
                      color: ColorsManager.textLight,
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 20.w,
                      vertical: 15.h,
                    ),
                  ),
                ),
              ),
            ),

            // Map Toggle
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Row(
                children: [
                  Text(
                    'Show Map',
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: ColorsManager.textSecondary,
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Switch(
                    value: _showMap,
                    onChanged: (value) {
                      setState(() {
                        _showMap = value;
                      });
                    },
                    activeThumbColor: ColorsManager.primaryBlue,
                  ),
                ],
              ),
            ),

            // Map Section (optional)
            if (_showMap) ...[
              Container(
                margin: EdgeInsets.all(16.w),
                height: 200.h,
                decoration: BoxDecoration(
                  color: ColorsManager.lightBlue,
                  borderRadius: BorderRadius.circular(12.w),
                  border: Border.all(color: ColorsManager.inputBorder),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.map,
                        size: 48.w,
                        color: ColorsManager.primaryBlue,
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        'Map View',
                        style: TextStyle(
                          fontSize: 16.sp,
                          color: ColorsManager.textSecondary,
                        ),
                      ),
                      Text(
                        'Google Maps integration',
                        style: TextStyle(
                          fontSize: 12.sp,
                          color: ColorsManager.textLight,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],

            // Search Results
            Expanded(
              child: _searchQuery.isEmpty
                  ? _buildInitialState()
                  : _buildSearchResults(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInitialState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search, size: 64.w, color: ColorsManager.textLight),
          SizedBox(height: 16.h),
          Text(
            'Search for doctors or specialties',
            style: TextStyle(
              fontSize: 16.sp,
              color: ColorsManager.textSecondary,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Find the best medical care',
            style: TextStyle(fontSize: 14.sp, color: ColorsManager.textLight),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    // Filter doctors based on search query
    final filteredDoctors = _allDoctors.where((doctor) {
      final query = _searchQuery.toLowerCase();
      return doctor['name'].toLowerCase().contains(query) ||
          doctor['specialty'].toLowerCase().contains(query) ||
          doctor['hospital'].toLowerCase().contains(query);
    }).toList();

    if (filteredDoctors.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off, size: 64.w, color: ColorsManager.textLight),
            SizedBox(height: 16.h),
            Text(
              'No doctors found',
              style: TextStyle(
                fontSize: 16.sp,
                color: ColorsManager.textSecondary,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              'Try different keywords',
              style: TextStyle(fontSize: 14.sp, color: ColorsManager.textLight),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      itemCount: filteredDoctors.length,
      itemBuilder: (context, index) {
        final doctor = filteredDoctors[index];
        return DoctorCard(
          doctor: doctor,
          onTap: () {
            // TODO: Navigate to doctor detail screen
          },
        );
      },
    );
  }

  // Mock data for all doctors
  final List<Map<String, dynamic>> _allDoctors = [
    {
      'name': 'Dr. Sarah Johnson',
      'specialty': 'Cardiologist',
      'hospital': 'City Heart Hospital',
      'rating': 4.8,
      'image': 'assets/images/doctors/doctor1.png',
    },
    {
      'name': 'Dr. Michael Chen',
      'specialty': 'Neurologist',
      'hospital': 'Neuro Care Center',
      'rating': 4.9,
      'image': 'assets/images/doctors/doctor2.png',
    },
    {
      'name': 'Dr. Emily Davis',
      'specialty': 'Pediatrician',
      'hospital': 'Children\'s Medical Center',
      'rating': 4.7,
      'image': 'assets/images/doctors/doctor3.png',
    },
    {
      'name': 'Dr. Robert Wilson',
      'specialty': 'Orthopedic',
      'hospital': 'Bone & Joint Institute',
      'rating': 4.6,
      'image': 'assets/images/doctors/doctor4.png',
    },
    {
      'name': 'Dr. Lisa Anderson',
      'specialty': 'Dermatologist',
      'hospital': 'Skin Care Clinic',
      'rating': 4.8,
      'image': 'assets/images/doctors/doctor5.png',
    },
    {
      'name': 'Dr. James Brown',
      'specialty': 'ENT Specialist',
      'hospital': 'Ear Nose Throat Center',
      'rating': 4.7,
      'image': 'assets/images/doctors/doctor6.png',
    },
    {
      'name': 'Dr. Maria Garcia',
      'specialty': 'Gynecologist',
      'hospital': 'Women\'s Health Center',
      'rating': 4.9,
      'image': 'assets/images/doctors/doctor7.png',
    },
    {
      'name': 'Dr. David Lee',
      'specialty': 'Psychiatrist',
      'hospital': 'Mental Health Institute',
      'rating': 4.5,
      'image': 'assets/images/doctors/doctor8.png',
    },
  ];
}
