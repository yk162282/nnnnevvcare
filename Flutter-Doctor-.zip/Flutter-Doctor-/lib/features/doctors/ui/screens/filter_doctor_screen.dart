import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';

class FilterDoctorScreen extends StatefulWidget {
  const FilterDoctorScreen({super.key});

  @override
  State<FilterDoctorScreen> createState() => _FilterDoctorScreenState();
}

class _FilterDoctorScreenState extends State<FilterDoctorScreen> {
  final List<String> _selectedSpecialties = [];
  String? _selectedLocation;
  double _rating = 0.0;
  bool _availableToday = false;

  final List<String> _specialties = [
    'General Physician',
    'Dentist',
    'Cardiologist',
    'Neurologist',
    'Orthopedic',
    'Pediatrician',
    'Dermatologist',
    'ENT Specialist',
    'Psychiatrist',
    'Gynecologist',
  ];

  final List<String> _locations = [
    'New York',
    'Los Angeles',
    'Chicago',
    'Houston',
    'Phoenix',
    'Philadelphia',
    'San Antonio',
    'San Diego',
    'Dallas',
    'San Jose',
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.w),
          topRight: Radius.circular(20.w),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: ColorsManager.inputBorder, width: 1),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Filter Doctors',
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: ColorsManager.textPrimary,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(Icons.close, color: ColorsManager.textLight),
                ),
              ],
            ),
          ),

          // Filter Content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(20.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Specialty Section
                  _buildSectionTitle('Specialty'),
                  SizedBox(height: 12.h),
                  _buildSpecialtyCheckboxes(),
                  SizedBox(height: 24.h),

                  // Location Section
                  _buildSectionTitle('Location'),
                  SizedBox(height: 12.h),
                  _buildLocationDropdown(),
                  SizedBox(height: 24.h),

                  // Rating Section
                  _buildSectionTitle('Minimum Rating'),
                  SizedBox(height: 12.h),
                  _buildRatingSlider(),
                  SizedBox(height: 24.h),

                  // Availability Section
                  _buildSectionTitle('Availability'),
                  SizedBox(height: 12.h),
                  _buildAvailabilitySwitch(),
                  SizedBox(height: 32.h),
                ],
              ),
            ),
          ),

          // Apply Button
          Container(
            padding: EdgeInsets.all(20.w),
            child: SizedBox(
              width: double.infinity,
              height: 50.h,
              child: ElevatedButton(
                onPressed: _applyFilters,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorsManager.primaryBlue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.w),
                  ),
                ),
                child: Text(
                  'Apply Filter',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 16.sp,
        fontWeight: FontWeight.bold,
        color: ColorsManager.textPrimary,
      ),
    );
  }

  Widget _buildSpecialtyCheckboxes() {
    return Wrap(
      spacing: 12.w,
      runSpacing: 12.h,
      children: _specialties.map((specialty) {
        final isSelected = _selectedSpecialties.contains(specialty);
        return GestureDetector(
          onTap: () {
            setState(() {
              if (isSelected) {
                _selectedSpecialties.remove(specialty);
              } else {
                _selectedSpecialties.add(specialty);
              }
            });
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
            decoration: BoxDecoration(
              color: isSelected ? ColorsManager.primaryBlue : Colors.white,
              borderRadius: BorderRadius.circular(20.w),
              border: Border.all(
                color: isSelected
                    ? ColorsManager.primaryBlue
                    : ColorsManager.inputBorder,
                width: 1,
              ),
            ),
            child: Text(
              specialty,
              style: TextStyle(
                fontSize: 14.sp,
                color: isSelected ? Colors.white : ColorsManager.textSecondary,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildLocationDropdown() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: ColorsManager.inputBackground,
        borderRadius: BorderRadius.circular(8.w),
        border: Border.all(color: ColorsManager.inputBorder, width: 1),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedLocation,
          hint: Text(
            'Select Location',
            style: TextStyle(color: ColorsManager.textLight, fontSize: 14.sp),
          ),
          items: _locations.map((location) {
            return DropdownMenuItem(
              value: location,
              child: Text(
                location,
                style: TextStyle(
                  fontSize: 14.sp,
                  color: ColorsManager.textPrimary,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedLocation = value;
            });
          },
          icon: Icon(Icons.arrow_drop_down, color: ColorsManager.textLight),
        ),
      ),
    );
  }

  Widget _buildRatingSlider() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              _rating.toStringAsFixed(1),
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.bold,
                color: ColorsManager.primaryBlue,
              ),
            ),
            Row(
              children: List.generate(5, (index) {
                return Icon(
                  index < _rating ? Icons.star : Icons.star_border,
                  size: 20.w,
                  color: index < _rating
                      ? Colors.amber
                      : ColorsManager.textLight,
                );
              }),
            ),
          ],
        ),
        Slider(
          value: _rating,
          min: 0.0,
          max: 5.0,
          divisions: 10,
          activeColor: ColorsManager.primaryBlue,
          inactiveColor: ColorsManager.inputBorder,
          onChanged: (value) {
            setState(() {
              _rating = value;
            });
          },
        ),
      ],
    );
  }

  Widget _buildAvailabilitySwitch() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: ColorsManager.inputBackground,
        borderRadius: BorderRadius.circular(8.w),
        border: Border.all(color: ColorsManager.inputBorder, width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Available Today',
            style: TextStyle(fontSize: 14.sp, color: ColorsManager.textPrimary),
          ),
          Switch(
            value: _availableToday,
            onChanged: (value) {
              setState(() {
                _availableToday = value;
              });
            },
            activeThumbColor: ColorsManager.primaryBlue,
          ),
        ],
      ),
    );
  }

  void _applyFilters() {
    // TODO: Apply filters and navigate back with results
    final filters = {
      'specialties': _selectedSpecialties,
      'location': _selectedLocation,
      'rating': _rating,
      'availableToday': _availableToday,
    };

    Navigator.pop(context, filters);
  }
}
