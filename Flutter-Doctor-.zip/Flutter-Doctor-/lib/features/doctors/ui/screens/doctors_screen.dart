import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';
import '../../../../core/routing/routes.dart';
import '../widgets/doctor_search_bar.dart';

import '../widgets/doctor_list_item.dart';

class DoctorsScreen extends StatefulWidget {
  const DoctorsScreen({super.key});

  @override
  State<DoctorsScreen> createState() => _DoctorsScreenState();
}

class _DoctorsScreenState extends State<DoctorsScreen> {
  String _searchQuery = '';
  String _selectedSpecialization = 'All';
  String _selectedCity = 'All';
  double _selectedRating = 0.0;
  bool _isAvailableOnly = false;

  final List<String> _specializations = [
    'All',
    'Cardiologist',
    'Neurologist',
    'Pediatrician',
    'Orthopedic',
    'Dermatologist',
    'Psychiatrist',
    'Gynecologist',
    'ENT',
    'Dental',
  ];

  final List<String> _cities = [
    'All',
    'New York',
    'Los Angeles',
    'Chicago',
    'Houston',
    'Phoenix',
    'Miami',
    'San Francisco',
    'Boston',
    'Seattle',
  ];

  final List<Map<String, dynamic>> _doctors = [
    {
      'id': 1,
      'name': 'Dr. Sarah Johnson',
      'specialization': 'Cardiologist',
      'city': 'New York',
      'rating': 4.8,
      'experience': '15 years',
      'consultationFee': 150.0,
      'isAvailable': true,
      'image': 'assets/images/doctor1.jpg',
    },
    {
      'id': 2,
      'name': 'Dr. Michael Chen',
      'specialization': 'Neurologist',
      'city': 'Los Angeles',
      'rating': 4.9,
      'experience': '12 years',
      'consultationFee': 180.0,
      'isAvailable': true,
      'image': 'assets/images/doctor2.jpg',
    },
    {
      'id': 3,
      'name': 'Dr. Emily Davis',
      'specialization': 'Pediatrician',
      'city': 'Chicago',
      'rating': 4.7,
      'experience': '8 years',
      'consultationFee': 120.0,
      'isAvailable': false,
      'image': 'assets/images/doctor3.jpg',
    },
    {
      'id': 4,
      'name': 'Dr. Robert Wilson',
      'specialization': 'Orthopedic',
      'city': 'Houston',
      'rating': 4.6,
      'experience': '20 years',
      'consultationFee': 200.0,
      'isAvailable': true,
      'image': 'assets/images/doctor4.jpg',
    },
    {
      'id': 5,
      'name': 'Dr. Lisa Brown',
      'specialization': 'Dermatologist',
      'city': 'Phoenix',
      'rating': 4.8,
      'experience': '10 years',
      'consultationFee': 140.0,
      'isAvailable': true,
      'image': 'assets/images/doctor5.jpg',
    },
    {
      'id': 6,
      'name': 'Dr. James Miller',
      'specialization': 'Psychiatrist',
      'city': 'Miami',
      'rating': 4.5,
      'experience': '18 years',
      'consultationFee': 160.0,
      'isAvailable': true,
      'image': 'assets/images/doctor6.jpg',
    },
    {
      'id': 7,
      'name': 'Dr. Maria Garcia',
      'specialization': 'Gynecologist',
      'city': 'San Francisco',
      'rating': 4.9,
      'experience': '14 years',
      'consultationFee': 170.0,
      'isAvailable': false,
      'image': 'assets/images/doctor7.jpg',
    },
  ];

  List<Map<String, dynamic>> get _filteredDoctors {
    return _doctors.where((doctor) {
      final matchesSearch =
          doctor['name'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          ) ||
          doctor['specialization'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          ) ||
          doctor['city'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          );

      final matchesSpecialization =
          _selectedSpecialization == 'All' ||
          doctor['specialization'] == _selectedSpecialization;

      final matchesCity =
          _selectedCity == 'All' || doctor['city'] == _selectedCity;

      final matchesRating = doctor['rating'] >= _selectedRating;

      final matchesAvailability = !_isAvailableOnly || doctor['isAvailable'];

      return matchesSearch &&
          matchesSpecialization &&
          matchesCity &&
          matchesRating &&
          matchesAvailability;
    }).toList();
  }

  void _clearAllFilters() {
    setState(() {
      _searchQuery = '';
      _selectedSpecialization = 'All';
      _selectedCity = 'All';
      _selectedRating = 0.0;
      _isAvailableOnly = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.moreLightGray,
      appBar: AppBar(
        title: Text(
          'Find Doctors',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 20.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black87),
        actions: [
          if (_hasActiveFilters())
            TextButton(
              onPressed: _clearAllFilters,
              child: Text(
                'Clear All',
                style: TextStyle(
                  color: ColorsManager.primaryBlue,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Compact Advanced Search & Filter Section
          Container(
            padding: EdgeInsets.all(16.w),
            child: Column(
              children: [
                // Search Bar
                DoctorSearchBar(
                  onSearchChanged: (query) {
                    setState(() {
                      _searchQuery = query;
                    });
                  },
                ),
                SizedBox(height: 16.h),

                // Compact Filter Section
                _buildCompactFilters(),

                // Results Count
                if (_filteredDoctors.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 12.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${_filteredDoctors.length} doctors found',
                          style: TextStyle(
                            color: ColorsManager.textSecondary,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (_hasActiveFilters())
                          Text(
                            'Filters applied',
                            style: TextStyle(
                              color: ColorsManager.primaryBlue,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ),

          // Doctors List
          Expanded(
            child: _filteredDoctors.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    itemCount: _filteredDoctors.length,
                    itemBuilder: (context, index) {
                      final doctor = _filteredDoctors[index];
                      return DoctorListItem(
                        doctor: doctor,
                        onTap: () {
                          Navigator.pushNamed(
                            context,
                            Routes.doctorDetailScreen,
                            arguments: doctor,
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactFilters() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Specialty and City Filters in Horizontal Layout
        Row(
          children: [
            // Specialty Filter
            Expanded(
              child: _buildCompactFilterDropdown(
                label: 'Specialty',
                value: _selectedSpecialization,
                items: _specializations,
                onChanged: (value) {
                  setState(() {
                    _selectedSpecialization = value ?? 'All';
                  });
                },
              ),
            ),
            SizedBox(width: 12.w),
            // City Filter
            Expanded(
              child: _buildCompactFilterDropdown(
                label: 'City',
                value: _selectedCity,
                items: _cities,
                onChanged: (value) {
                  setState(() {
                    _selectedCity = value ?? 'All';
                  });
                },
              ),
            ),
          ],
        ),
        SizedBox(height: 16.h),

        // Rating and Availability in Compact Row
        Row(
          children: [
            // Rating Filter
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Min Rating: ${_selectedRating > 0 ? '${_selectedRating.toStringAsFixed(1)}+' : 'Any'}',
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: ColorsManager.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Slider(
                    value: _selectedRating,
                    min: 0.0,
                    max: 5.0,
                    divisions: 10,
                    activeColor: ColorsManager.primaryBlue,
                    inactiveColor: ColorsManager.textLight.withValues(
                      alpha: 0.3,
                    ),
                    onChanged: (value) {
                      setState(() {
                        _selectedRating = value;
                      });
                    },
                  ),
                ],
              ),
            ),
            SizedBox(width: 16.w),
            // Availability Filter
            Expanded(
              flex: 1,
              child: Row(
                children: [
                  Checkbox(
                    value: _isAvailableOnly,
                    onChanged: (value) {
                      setState(() {
                        _isAvailableOnly = value ?? false;
                      });
                    },
                    activeColor: ColorsManager.primaryBlue,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  Expanded(
                    child: Text(
                      'Available only',
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: ColorsManager.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCompactFilterDropdown({
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12.sp,
            color: ColorsManager.textSecondary,
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 4.h),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8.w),
            border: Border.all(
              color: ColorsManager.textLight.withValues(alpha: 0.3),
            ),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              icon: Icon(Icons.arrow_drop_down, size: 20.w),
              style: TextStyle(
                fontSize: 14.sp,
                color: ColorsManager.textPrimary,
                fontWeight: FontWeight.w500,
              ),
              items: items.map((String item) {
                return DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item,
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: item == 'All'
                          ? ColorsManager.textSecondary
                          : ColorsManager.textPrimary,
                    ),
                  ),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off, size: 64.w, color: ColorsManager.gray),
          SizedBox(height: 16.h),
          Text(
            'No doctors found',
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
              color: ColorsManager.gray,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Try adjusting your search or filters',
            style: TextStyle(fontSize: 14.sp, color: ColorsManager.gray),
          ),
          SizedBox(height: 16.h),
          ElevatedButton(
            onPressed: _clearAllFilters,
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorsManager.primaryBlue,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
            ),
            child: Text('Clear All Filters'),
          ),
        ],
      ),
    );
  }

  bool _hasActiveFilters() {
    return _searchQuery.isNotEmpty ||
        _selectedSpecialization != 'All' ||
        _selectedCity != 'All' ||
        _selectedRating > 0.0 ||
        _isAvailableOnly;
  }
}
