import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';

class DoctorFilterChips extends StatelessWidget {
  final String selectedSpecialization;
  final String selectedCity;
  final ValueChanged<String> onSpecializationChanged;
  final ValueChanged<String> onCityChanged;

  const DoctorFilterChips({
    super.key,
    required this.selectedSpecialization,
    required this.selectedCity,
    required this.onSpecializationChanged,
    required this.onCityChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Specialization Filter
        Text(
          'Specialization',
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        SizedBox(height: 12.h),
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: [
            'All',
            'Cardiologist',
            'Neurologist',
            'Pediatrician',
            'Orthopedic',
            'Dermatologist',
          ].map((specialization) {
            return FilterChip(
              label: Text(
                specialization,
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: selectedSpecialization == specialization
                      ? Colors.white
                      : ColorsManager.gray,
                ),
              ),
              selected: selectedSpecialization == specialization,
              onSelected: (selected) {
                if (selected) {
                  onSpecializationChanged(specialization);
                }
              },
              backgroundColor: ColorsManager.moreLightGray,
              selectedColor: ColorsManager.mainBlue,
              checkmarkColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.w),
              ),
            );
          }).toList(),
        ),

        SizedBox(height: 20.h),

        // City Filter
        Text(
          'City',
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        SizedBox(height: 12.h),
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: [
            'All',
            'New York',
            'Los Angeles',
            'Chicago',
            'Houston',
            'Phoenix',
          ].map((city) {
            return FilterChip(
              label: Text(
                city,
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: selectedCity == city
                      ? Colors.white
                      : ColorsManager.gray,
                ),
              ),
              selected: selectedCity == city,
              onSelected: (selected) {
                if (selected) {
                  onCityChanged(city);
                }
              },
              backgroundColor: ColorsManager.moreLightGray,
              selectedColor: ColorsManager.mainBlue,
              checkmarkColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.w),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
