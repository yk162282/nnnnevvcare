import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';

class DoctorListItem extends StatelessWidget {
  final Map<String, dynamic> doctor;
  final VoidCallback onTap;

  const DoctorListItem({
    super.key,
    required this.doctor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16.w),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Row(
              children: [
                // Doctor Avatar
                Container(
                  width: 60.w,
                  height: 60.w,
                  decoration: BoxDecoration(
                    color: ColorsManager.lightBlue,
                    borderRadius: BorderRadius.circular(30.w),
                  ),
                  child: Icon(
                    Icons.medical_services,
                    color: ColorsManager.mainBlue,
                    size: 30.w,
                  ),
                ),

                SizedBox(width: 16.w),

                // Doctor Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        doctor['name'] as String,
                        style: TextStyle(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        doctor['specialization'] as String,
                        style: TextStyle(
                          fontSize: 14.sp,
                          color: ColorsManager.gray,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 14.w,
                            color: ColorsManager.gray,
                          ),
                          SizedBox(width: 4.w),
                          Text(
                            doctor['city'] as String,
                            style: TextStyle(
                              fontSize: 12.sp,
                              color: ColorsManager.gray,
                            ),
                          ),
                          SizedBox(width: 16.w),
                          Icon(
                            Icons.star,
                            size: 14.w,
                            color: Colors.amber,
                          ),
                          SizedBox(width: 4.w),
                          Text(
                            '${doctor['rating']}',
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Right Side Info
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    // Availability Status
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 8.w,
                        vertical: 4.h,
                      ),
                      decoration: BoxDecoration(
                        color: (doctor['isAvailable'] as bool)
                            ? Colors.green.withOpacity(0.1)
                            : Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12.w),
                      ),
                      child: Text(
                        (doctor['isAvailable'] as bool) ? 'Available' : 'Busy',
                        style: TextStyle(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                          color: (doctor['isAvailable'] as bool)
                              ? Colors.green
                              : Colors.red,
                        ),
                      ),
                    ),
                    SizedBox(height: 8.h),
                    
                    // Consultation Fee
                    Text(
                      '\$${doctor['consultationFee']}',
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: ColorsManager.mainBlue,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      'per visit',
                      style: TextStyle(
                        fontSize: 10.sp,
                        color: ColorsManager.gray,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
