import 'package:json_annotation/json_annotation.dart';

part 'doctor.g.dart';

@JsonSerializable()
class Doctor {
  final int id;
  final String name;
  final String email;
  final String phone;
  final String? image;
  final String? bio;
  final double rating;
  final int experienceYears;
  final String specialization;
  final String city;
  final String governrate;
  final double consultationFee;
  final List<String> availableDays;
  final List<String> availableTimes;
  final bool isAvailable;

  Doctor({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.image,
    this.bio,
    required this.rating,
    required this.experienceYears,
    required this.specialization,
    required this.city,
    required this.governrate,
    required this.consultationFee,
    required this.availableDays,
    required this.availableTimes,
    required this.isAvailable,
  });

  factory Doctor.fromJson(Map<String, dynamic> json) => _$DoctorFromJson(json);

  Map<String, dynamic> toJson() => _$DoctorToJson(this);
}
