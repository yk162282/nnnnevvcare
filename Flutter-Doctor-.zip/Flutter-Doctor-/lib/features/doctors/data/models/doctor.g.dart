// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Doctor _$DoctorFromJson(Map<String, dynamic> json) => Doctor(
  id: (json['id'] as num).toInt(),
  name: json['name'] as String,
  email: json['email'] as String,
  phone: json['phone'] as String,
  image: json['image'] as String?,
  bio: json['bio'] as String?,
  rating: (json['rating'] as num).toDouble(),
  experienceYears: (json['experienceYears'] as num).toInt(),
  specialization: json['specialization'] as String,
  city: json['city'] as String,
  governrate: json['governrate'] as String,
  consultationFee: (json['consultationFee'] as num).toDouble(),
  availableDays: (json['availableDays'] as List<dynamic>)
      .map((e) => e as String)
      .toList(),
  availableTimes: (json['availableTimes'] as List<dynamic>)
      .map((e) => e as String)
      .toList(),
  isAvailable: json['isAvailable'] as bool,
);

Map<String, dynamic> _$DoctorToJson(Doctor instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
  'email': instance.email,
  'phone': instance.phone,
  'image': instance.image,
  'bio': instance.bio,
  'rating': instance.rating,
  'experienceYears': instance.experienceYears,
  'specialization': instance.specialization,
  'city': instance.city,
  'governrate': instance.governrate,
  'consultationFee': instance.consultationFee,
  'availableDays': instance.availableDays,
  'availableTimes': instance.availableTimes,
  'isAvailable': instance.isAvailable,
};
