import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';

class AppointmentsScreen extends StatelessWidget {
  const AppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.moreLightGray,
      appBar: AppBar(
        title: Text(
          'My Appointments',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 20.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black87),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.w),
        child: Column(
          children: [
            _buildAppointmentList(),
          ],
        ),
      ),
    );
  }

  Widget _buildAppointmentList() {
    final appointments = [
      {
        'doctorName': 'Dr. Sarah Johnson',
        'specialization': 'Cardiologist',
        'date': 'Today, 2:00 PM',
        'status': 'confirmed',
        'type': 'In-person',
      },
      {
        'doctorName': 'Dr. Michael Chen',
        'specialization': 'Neurologist',
        'date': 'Tomorrow, 10:00 AM',
        'status': 'pending',
        'type': 'Video Call',
      },
      {
        'doctorName': 'Dr. Emily Davis',
        'specialization': 'Pediatrician',
        'date': 'Dec 25, 3:30 PM',
        'status': 'confirmed',
        'type': 'In-person',
      },
    ];

    return Column(
      children: appointments.map((appointment) {
        return _buildAppointmentCard(appointment);
      }).toList(),
    );
  }

  Widget _buildAppointmentCard(Map<String, String> appointment) {
    final status = appointment['status'] as String;
    final statusColor = _getStatusColor(status);
    final statusText = _getStatusText(status);

    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with Doctor Info
          Row(
            children: [
              Container(
                width: 50.w,
                height: 50.w,
                decoration: BoxDecoration(
                  color: ColorsManager.lightBlue,
                  borderRadius: BorderRadius.circular(25.w),
                ),
                child: Icon(
                  Icons.medical_services,
                  color: ColorsManager.mainBlue,
                  size: 24.w,
                ),
              ),
              SizedBox(width: 16.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      appointment['doctorName'] as String,
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    Text(
                      appointment['specialization'] as String,
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: ColorsManager.gray,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20.w),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 20.h),
          
          // Appointment Details
          Row(
            children: [
              Icon(
                Icons.calendar_today,
                size: 16.w,
                color: ColorsManager.gray,
              ),
              SizedBox(width: 8.w),
              Text(
                appointment['date'] as String,
                style: TextStyle(
                  fontSize: 14.sp,
                  color: ColorsManager.gray,
                ),
              ),
              SizedBox(width: 24.w),
              Icon(
                Icons.video_call,
                size: 16.w,
                color: ColorsManager.gray,
              ),
              SizedBox(width: 8.w),
              Text(
                appointment['type'] as String,
                style: TextStyle(
                  fontSize: 14.sp,
                  color: ColorsManager.gray,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'confirmed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      default:
        return ColorsManager.gray;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'confirmed':
        return 'Confirmed';
      case 'pending':
        return 'Pending';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  }
}
