import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';

class BookingAppointmentScreen extends StatefulWidget {
  final Map<String, dynamic> doctor;

  const BookingAppointmentScreen({
    super.key,
    required this.doctor,
  });

  @override
  State<BookingAppointmentScreen> createState() => _BookingAppointmentScreenState();
}

class _BookingAppointmentScreenState extends State<BookingAppointmentScreen> {
  int _currentStep = 0;
  DateTime? _selectedDate;
  String? _selectedTime;
  String? _selectedPaymentMethod;
  bool _isLoading = false;

  final List<String> _timeSlots = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
    '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM',
    '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM',
  ];

  final List<Map<String, dynamic>> _paymentMethods = [
    {
      'name': 'Visa',
      'logo': '💳',
      'description': '•••• •••• •••• 1234',
    },
    {
      'name': 'PayPal',
      'logo': '🔵',
      'description': 'paypal@email.com',
    },
    {
      'name': 'Cash',
      'logo': '💵',
      'description': 'Pay at clinic',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: ColorsManager.textPrimary,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Book Appointment',
          style: TextStyle(
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
            color: ColorsManager.textPrimary,
          ),
        ),
      ),
      body: Column(
        children: [
          // Progress Indicator
          _buildProgressIndicator(),
          
          // Content
          Expanded(
            child: _buildStepContent(),
          ),
          
          // Navigation Buttons
          _buildNavigationButtons(),
        ],
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: EdgeInsets.all(20.w),
      child: Row(
        children: List.generate(4, (index) {
          final isActive = index <= _currentStep;
          final isCompleted = index < _currentStep;
          
          return Expanded(
            child: Row(
              children: [
                Container(
                  width: 32.w,
                  height: 32.w,
                  decoration: BoxDecoration(
                    color: isCompleted 
                        ? ColorsManager.success 
                        : isActive 
                            ? ColorsManager.primaryBlue 
                            : ColorsManager.inputBorder,
                    shape: BoxShape.circle,
                  ),
                  child: isCompleted
                      ? Icon(
                          Icons.check,
                          size: 20.w,
                          color: Colors.white,
                        )
                      : Text(
                          '${index + 1}',
                          style: TextStyle(
                            color: isActive ? Colors.white : ColorsManager.textLight,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
                if (index < 3)
                  Expanded(
                    child: Container(
                      height: 2.h,
                      color: isCompleted 
                          ? ColorsManager.success 
                          : ColorsManager.inputBorder,
                    ),
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildDateTimeStep();
      case 1:
        return _buildPaymentStep();
      case 2:
        return _buildSummaryStep();
      case 3:
        return _buildConfirmationStep();
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildDateTimeStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Date & Time',
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 24.h),
          
          // Calendar
          Text(
            'Available Dates',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: ColorsManager.textSecondary,
            ),
          ),
          SizedBox(height: 16.h),
          
          SizedBox(
            height: 100.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 14,
              itemBuilder: (context, index) {
                final date = DateTime.now().add(Duration(days: index));
                final isSelected = _selectedDate?.day == date.day;
                
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedDate = date;
                    });
                  },
                  child: Container(
                    width: 80.w,
                    margin: EdgeInsets.only(right: 12.w),
                    decoration: BoxDecoration(
                      color: isSelected ? ColorsManager.primaryBlue : Colors.white,
                      borderRadius: BorderRadius.circular(12.w),
                      border: Border.all(
                        color: isSelected ? ColorsManager.primaryBlue : ColorsManager.inputBorder,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          _getDayName(date.weekday),
                          style: TextStyle(
                            fontSize: 12.sp,
                            color: isSelected ? Colors.white : ColorsManager.textLight,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          '${date.day}',
                          style: TextStyle(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                            color: isSelected ? Colors.white : ColorsManager.textPrimary,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          _getMonthName(date.month),
                          style: TextStyle(
                            fontSize: 10.sp,
                            color: isSelected ? Colors.white : ColorsManager.textLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          
          SizedBox(height: 32.h),
          
          // Time Slots
          Text(
            'Available Time Slots',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: ColorsManager.textSecondary,
            ),
          ),
          SizedBox(height: 16.h),
          
          Wrap(
            spacing: 12.w,
            runSpacing: 12.h,
            children: _timeSlots.map((time) {
              final isSelected = _selectedTime == time;
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedTime = time;
                  });
                },
                child: Container(
                  width: 80.w,
                  height: 40.h,
                  decoration: BoxDecoration(
                    color: isSelected ? ColorsManager.primaryBlue : Colors.white,
                    borderRadius: BorderRadius.circular(20.w),
                    border: Border.all(
                      color: isSelected ? ColorsManager.primaryBlue : ColorsManager.inputBorder,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      time,
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: isSelected ? Colors.white : ColorsManager.textSecondary,
                        fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Payment Method',
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 24.h),
          
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _paymentMethods.length,
            itemBuilder: (context, index) {
              final method = _paymentMethods[index];
              final isSelected = _selectedPaymentMethod == method['name'];
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedPaymentMethod = method['name'];
                  });
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: 16.h),
                  padding: EdgeInsets.all(16.w),
                  decoration: BoxDecoration(
                    color: isSelected ? ColorsManager.lightBlue : Colors.white,
                    borderRadius: BorderRadius.circular(12.w),
                    border: Border.all(
                      color: isSelected ? ColorsManager.primaryBlue : ColorsManager.inputBorder,
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Radio<String>(
                        value: method['name'],
                        groupValue: _selectedPaymentMethod,
                        onChanged: (value) {
                          setState(() {
                            _selectedPaymentMethod = value;
                          });
                        },
                        activeColor: ColorsManager.primaryBlue,
                      ),
                      SizedBox(width: 16.w),
                      Text(
                        method['logo'],
                        style: TextStyle(fontSize: 24.sp),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              method['name'],
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w600,
                                color: ColorsManager.textPrimary,
                              ),
                            ),
                            Text(
                              method['description'],
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: ColorsManager.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryStep() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Appointment Summary',
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 24.h),
          
          Container(
            padding: EdgeInsets.all(20.w),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16.w),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                // Doctor Info
                Row(
                  children: [
                    Container(
                      width: 60.w,
                      height: 60.w,
                      decoration: BoxDecoration(
                        color: ColorsManager.lightBlue,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.person,
                        size: 30.w,
                        color: ColorsManager.primaryBlue,
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.doctor['name'] ?? 'Dr. Unknown',
                            style: TextStyle(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.bold,
                              color: ColorsManager.textPrimary,
                            ),
                          ),
                          Text(
                            widget.doctor['specialty'] ?? 'Specialist',
                            style: TextStyle(
                              fontSize: 14.sp,
                              color: ColorsManager.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                
                SizedBox(height: 24.h),
                
                // Appointment Details
                _buildSummaryRow('Date', _getFormattedDate()),
                _buildSummaryRow('Time', _selectedTime ?? 'Not selected'),
                _buildSummaryRow('Type', 'In-person consultation'),
                _buildSummaryRow('Payment', _selectedPaymentMethod ?? 'Not selected'),
                
                SizedBox(height: 24.h),
                
                // Total
                Container(
                  padding: EdgeInsets.symmetric(vertical: 16.h),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: ColorsManager.inputBorder,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Total',
                        style: TextStyle(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                          color: ColorsManager.textPrimary,
                        ),
                      ),
                      Text(
                        '\$150.00',
                        style: TextStyle(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                          color: ColorsManager.primaryBlue,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConfirmationStep() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Success Animation
            Container(
              width: 120.w,
              height: 120.w,
              decoration: BoxDecoration(
                color: ColorsManager.success,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.check,
                size: 60.w,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 32.h),
            
            Text(
              'Appointment Confirmed!',
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: ColorsManager.textPrimary,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            
            Text(
              'Your appointment has been successfully scheduled. You will receive a confirmation email shortly.',
              style: TextStyle(
                fontSize: 16.sp,
                color: ColorsManager.textSecondary,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 32.h),
            
            // Appointment Details
            Container(
              padding: EdgeInsets.all(20.w),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16.w),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildSummaryRow('Doctor', widget.doctor['name'] ?? 'Dr. Unknown'),
                  _buildSummaryRow('Date', _getFormattedDate()),
                  _buildSummaryRow('Time', _selectedTime ?? 'Not selected'),
                  _buildSummaryRow('Reference', '#APT${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14.sp,
              color: ColorsManager.textSecondary,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: ColorsManager.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Container(
      padding: EdgeInsets.all(20.w),
      child: Row(
        children: [
          if (_currentStep > 0)
            Expanded(
              child: SizedBox(
                height: 50.h,
                child: OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _currentStep--;
                    });
                  },
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: ColorsManager.primaryBlue),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25.w),
                    ),
                  ),
                  child: Text(
                    'Back',
                    style: TextStyle(
                      color: ColorsManager.primaryBlue,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          if (_currentStep > 0) SizedBox(width: 16.w),
          Expanded(
            child: SizedBox(
              height: 50.h,
              child: ElevatedButton(
                onPressed: _canProceed() ? _handleNext : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorsManager.primaryBlue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.w),
                  ),
                ),
                child: _isLoading
                    ? SizedBox(
                        width: 20.w,
                        height: 20.w,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : Text(
                        _currentStep == 3 ? 'Done' : 'Continue',
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  bool _canProceed() {
    switch (_currentStep) {
      case 0:
        return _selectedDate != null && _selectedTime != null;
      case 1:
        return _selectedPaymentMethod != null;
      case 2:
        return true;
      case 3:
        return true;
      default:
        return false;
    }
  }

  void _handleNext() async {
    if (_currentStep < 3) {
      if (_currentStep == 2) {
        // Simulate payment processing
        setState(() {
          _isLoading = true;
        });
        
        await Future.delayed(const Duration(seconds: 2));
        
        setState(() {
          _isLoading = false;
        });
      }
      
      setState(() {
        _currentStep++;
      });
    } else {
      // Navigate back to home or appointments screen
      Navigator.pop(context);
    }
  }

  String _getDayName(int weekday) {
    switch (weekday) {
      case 1: return 'Mon';
      case 2: return 'Tue';
      case 3: return 'Wed';
      case 4: return 'Thu';
      case 5: return 'Fri';
      case 6: return 'Sat';
      case 7: return 'Sun';
      default: return '';
    }
  }

  String _getMonthName(int month) {
    switch (month) {
      case 1: return 'Jan';
      case 2: return 'Feb';
      case 3: return 'Mar';
      case 4: return 'Apr';
      case 5: return 'May';
      case 6: return 'Jun';
      case 7: return 'Jul';
      case 8: return 'Aug';
      case 9: return 'Sep';
      case 10: return 'Oct';
      case 11: return 'Nov';
      case 12: return 'Dec';
      default: return '';
    }
  }

  String _getFormattedDate() {
    if (_selectedDate == null) return 'Not selected';
    return '${_getDayName(_selectedDate!.weekday)}, ${_getMonthName(_selectedDate!.month)} ${_selectedDate!.day}';
  }
}
