import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theming/colors.dart';
import '../../../core/theming/text_styles.dart';

class PasswordStrengthIndicator extends StatelessWidget {
  final String password;

  const PasswordStrengthIndicator({
    super.key,
    required this.password,
  });

  @override
  Widget build(BuildContext context) {
    final strength = _calculatePasswordStrength();
    
    // Don't show indicator for empty password
    if (password.isEmpty) {
      return const SizedBox.shrink();
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Strength Bar
        Row(
          children: List.generate(4, (index) {
            Color barColor;
            if (index < strength) {
              barColor = _getStrengthColor(strength);
            } else {
              barColor = ColorsManager.lighterGray;
            }
            
            return Expanded(
              child: Container(
                height: 4.h,
                margin: EdgeInsets.only(right: index < 3 ? 4.w : 0),
                decoration: BoxDecoration(
                  color: barColor,
                  borderRadius: BorderRadius.circular(2.w),
                ),
              ),
            );
          }),
        ),
        SizedBox(height: 4.h),
        
        // Strength Text
        Text(
          _getStrengthText(strength),
          style: TextStyles.caption.copyWith(
            color: _getStrengthColor(strength),
          ),
        ),
      ],
    );
  }

  int _calculatePasswordStrength() {
    if (password.isEmpty) return 0;
    
    int score = 0;
    
    // Length check
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    
    // Character variety checks
    if (password.contains(RegExp(r'[a-z]'))) score++;
    if (password.contains(RegExp(r'[A-Z]'))) score++;
    if (password.contains(RegExp(r'[0-9]'))) score++;
    if (password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) score++;
    
    // Cap at 4
    return score > 4 ? 4 : score;
  }

  Color _getStrengthColor(int strength) {
    switch (strength) {
      case 0:
      case 1:
        return ColorsManager.error;
      case 2:
        return ColorsManager.warning;
      case 3:
        return ColorsManager.info;
      case 4:
        return ColorsManager.success;
      default:
        return ColorsManager.lighterGray;
    }
  }

  String _getStrengthText(int strength) {
    switch (strength) {
      case 0:
        return 'Very Weak';
      case 1:
        return 'Weak';
      case 2:
        return 'Fair';
      case 3:
        return 'Good';
      case 4:
        return 'Strong';
      default:
        return '';
    }
  }
}
