import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theming/colors.dart';
import '../../../core/theming/button_styles.dart';
import '../../../core/constants/app_constants.dart';

class SocialLoginButton extends StatelessWidget {
  final String provider;
  final IconData icon;
  final VoidCallback onPressed;

  const SocialLoginButton({
    super.key,
    required this.provider,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: AppConstants.socialButtonSize.w,
      height: AppConstants.socialButtonSize.h,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ButtonStyles.social,
        child: Icon(
          icon,
          size: AppConstants.iconSizeMedium.w,
          color: _getProviderColor(),
        ),
      ),
    );
  }

  Color _getProviderColor() {
    switch (provider.toLowerCase()) {
      case 'google':
        return const Color(0xFFDB4437);
      case 'facebook':
        return const Color(0xFF4267B2);
      case 'apple':
        return Colors.black;
      default:
        return ColorsManager.textPrimary;
    }
  }
}
