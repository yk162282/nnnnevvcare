import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theming/colors.dart';

class SignupHeader extends StatelessWidget {
  final VoidCallback onBackPressed;

  const SignupHeader({
    super.key,
    required this.onBackPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Back Button
        GestureDetector(
          onTap: onBackPressed,
          child: Container(
            width: 40.w,
            height: 40.w,
            decoration: BoxDecoration(
              color: ColorsManager.lightBlue,
              borderRadius: BorderRadius.circular(12.w),
            ),
            child: Icon(
              Icons.arrow_back_ios,
              size: 20.w,
              color: ColorsManager.mainBlue,
            ),
          ),
        ),

        SizedBox(width: 20.w),

        // Title
        Expanded(
          child: Text(
            'Create Account',
            style: TextStyle(
              fontSize: 24.sp,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    );
  }
}
