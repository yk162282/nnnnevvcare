import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';
import 'package:doctor_appointment_app/core/theming/text_styles.dart';
import 'package:doctor_appointment_app/core/theming/input_styles.dart';
import 'package:doctor_appointment_app/core/constants/app_constants.dart';
import 'package:doctor_appointment_app/core/routing/routes.dart';
import 'package:doctor_appointment_app/core/di/dependency_injection.dart';
import 'package:doctor_appointment_app/core/networking/api_service_interface.dart';
import 'package:doctor_appointment_app/core/providers/user_provider.dart';
import 'package:doctor_appointment_app/features/login/data/models/user_profile.dart';
import 'widgets/password_strength_indicator.dart';
import 'widgets/signup_header.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _isObscurePassword = true;
  bool _isObscureConfirmPassword = true;
  bool _isLoading = false;
  String _selectedCountryCode = '+1'; // Default to US
  String _selectedGender =
      '0'; // Default gender (0 for male, 1 for female - API format)

  // Country codes with flags
  final List<Map<String, String>> _countryCodes = [
    {'code': '+1', 'flag': '🇺🇸', 'name': 'US'},
    {'code': '+44', 'flag': '🇬🇧', 'name': 'UK'},
    {'code': '+91', 'flag': '🇮🇳', 'name': 'IN'},
    {'code': '+86', 'flag': '🇨🇳', 'name': 'CN'},
    {'code': '+81', 'flag': '🇯🇵', 'name': 'JP'},
    {'code': '+49', 'flag': '🇩🇪', 'name': 'DE'},
    {'code': '+33', 'flag': '🇫🇷', 'name': 'FR'},
    {'code': '+39', 'flag': '🇮🇹', 'name': 'IT'},
    {'code': '+34', 'flag': '🇪🇸', 'name': 'ES'},
    {'code': '+7', 'flag': '🇷🇺', 'name': 'RU'},
    {'code': '+55', 'flag': '🇧🇷', 'name': 'BR'},
    {'code': '+61', 'flag': '🇦🇺', 'name': 'AU'},
    {'code': '+52', 'flag': '🇲🇽', 'name': 'MX'},
    {'code': '+82', 'flag': '🇰🇷', 'name': 'KR'},
    {'code': '+31', 'flag': '🇳🇱', 'name': 'NL'},
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _handleSignup() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Get API service from dependency injection
        final apiService = getIt<ApiServiceInterface>();

        // Call the real signup API
        final response = await apiService.register(
          name: _nameController.text.trim(),
          email: _emailController.text.trim(),
          phone: '$_selectedCountryCode${_phoneController.text}',
          gender: _selectedGender,
          password: _passwordController.text,
          passwordConfirmation: _confirmPasswordController.text,
        );

        if (response.isSuccess && response.data != null) {
          // Extract user data and token from response
          final userData = response.data!;

          // Create user profile from API response
          final user = UserProfile(
            id: userData['id'] ?? 1,
            name: _nameController.text.trim(),
            email: _emailController.text.trim(),
            phone: '$_selectedCountryCode${_phoneController.text}',
            gender: _selectedGender == '0' ? 0 : 1, // Convert string to int
            image: userData['image'],
            createdAt: userData['created_at'] != null
                ? DateTime.parse(userData['created_at'])
                : DateTime.now(),
            updatedAt: userData['updated_at'] != null
                ? DateTime.parse(userData['updated_at'])
                : DateTime.now(),
          );

          // Set the user in the provider
          final userProvider = context.read<UserProvider>();
          userProvider.setUser(user);

          // Store authentication token if provided
          if (userData['token'] != null) {
            // TODO: Store token securely (SharedPreferences or secure storage)
            print('Auth token from signup: ${userData['token']}');
          }

          // Show success message
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Account created successfully!'),
                backgroundColor: Colors.green,
              ),
            );
          }

          // Navigate to fill profile after successful signup
          if (mounted) {
            Navigator.pushReplacementNamed(
              context,
              Routes.fillProfileScreen,
              arguments: {
                'name': _nameController.text.trim(),
                'email': _emailController.text.trim(),
                'phone': '$_selectedCountryCode${_phoneController.text}',
                'gender': _selectedGender,
              },
            );
          }
        } else {
          // Handle API error response
          final errorMessage =
              response.message ?? 'Signup failed. Please try again.';
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(errorMessage),
                backgroundColor: ColorsManager.error,
              ),
            );
          }
        }
      } catch (e) {
        // Handle network or other errors
        String errorMessage = 'Signup failed. Please try again.';

        if (e.toString().contains('Connection failed') ||
            e.toString().contains('Network is unreachable')) {
          errorMessage = 'No internet connection. Please check your network.';
        } else if (e.toString().contains('timeout')) {
          errorMessage = 'Request timeout. Please try again.';
        } else if (e.toString().contains('422')) {
          errorMessage = 'Invalid data. Please check your information.';
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: ColorsManager.error,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Navigate to login screen instead of closing the app
        Navigator.pushReplacementNamed(context, Routes.loginScreen);
        return false; // Prevent default back behavior
      },
      child: Scaffold(
        backgroundColor: ColorsManager.background,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, color: ColorsManager.textPrimary),
            onPressed: () {
              // Navigate to login screen
              Navigator.pushReplacementNamed(context, Routes.loginScreen);
            },
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(
              horizontal: AppConstants.screenPaddingHorizontal.w,
              vertical: AppConstants.screenPaddingVertical.h,
            ),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  SignupHeader(
                    onBackPressed: () {
                      // Navigate to login screen
                      Navigator.pushReplacementNamed(
                        context,
                        Routes.loginScreen,
                      );
                    },
                  ),

                  SizedBox(height: AppConstants.spacingXL.h),

                  // Title
                  Text('Create Account', style: TextStyles.authTitle),
                  SizedBox(height: AppConstants.spacingS.h),
                  Text(
                    'Join VCare and start your health journey today',
                    style: TextStyles.authSubtitle,
                  ),
                  SizedBox(height: AppConstants.spacingXL.h),

                  // Full Name Field
                  TextFormField(
                    controller: _nameController,
                    decoration: InputStyles.nameInput,
                    style: InputStyles.textFieldStyle,
                    textCapitalization: TextCapitalization.words,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your full name';
                      }
                      if (value.length < AppConstants.nameMinLength) {
                        return 'Name must be at least ${AppConstants.nameMinLength} characters';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: AppConstants.spacingL.h),

                  // Email Field
                  TextFormField(
                    controller: _emailController,
                    decoration: InputStyles.emailInput,
                    style: InputStyles.textFieldStyle,
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your email';
                      }
                      if (!RegExp(
                        r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                      ).hasMatch(value)) {
                        return 'Please enter a valid email';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: AppConstants.spacingL.h),

                  // Phone Field with Country Code
                  Row(
                    children: [
                      // Country Code Dropdown
                      Container(
                        width: 90.w, // Increased from 80.w to fit flags + codes
                        height: AppConstants.inputFieldHeight.h,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: ColorsManager.inputBorder,
                            width: AppConstants.inputFieldBorderWidth,
                          ),
                          borderRadius: BorderRadius.circular(
                            AppConstants.inputFieldRadius.w,
                          ),
                          color: ColorsManager.inputBackground,
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _selectedCountryCode,
                            items: _countryCodes.map((country) {
                              return DropdownMenuItem(
                                value: country['code'],
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 8.w,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment
                                        .center, // Center the content
                                    children: [
                                      Text(
                                        country['flag']!,
                                        style: TextStyles.bodyMedium,
                                      ),
                                      SizedBox(width: AppConstants.spacingS.w),
                                      Text(
                                        country['name']!,
                                        style: TextStyles.bodyMedium,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedCountryCode = value!;
                              });
                            },
                            icon: Icon(
                              Icons.arrow_drop_down,
                              color: ColorsManager.textLight,
                            ),
                            // Show flag + country code in main display with smaller text
                            selectedItemBuilder: (context) {
                              return _countryCodes.map((country) {
                                return Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 8.w,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment
                                        .center, // Center the content
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        country['flag']!,
                                        style: TextStyles.bodyMedium,
                                      ),
                                      SizedBox(width: 4.w), // Reduced spacing
                                      Text(
                                        country['code']!,
                                        style: TextStyles.bodySmall.copyWith(
                                          // Smaller text
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList();
                            },
                          ),
                        ),
                      ),
                      SizedBox(width: AppConstants.spacingS.w),

                      // Phone Number Field
                      Expanded(
                        child: TextFormField(
                          controller: _phoneController,
                          decoration: InputStyles.phoneInput.copyWith(
                            hintText: 'Phone Number',
                          ),
                          style: InputStyles.textFieldStyle,
                          keyboardType: TextInputType.phone,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (value.length < AppConstants.phoneMinLength) {
                              return 'Phone number must be at least ${AppConstants.phoneMinLength} digits';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: AppConstants.spacingL.h),

                  // Gender Field
                  Container(
                    width: double.infinity,
                    height: AppConstants.inputFieldHeight.h,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: ColorsManager.inputBorder,
                        width: AppConstants.inputFieldBorderWidth,
                      ),
                      borderRadius: BorderRadius.circular(
                        AppConstants.inputFieldRadius.w,
                      ),
                      color: ColorsManager.inputBackground,
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _selectedGender,
                        hint: Text(
                          'Select Gender',
                          style: TextStyles.inputHint,
                        ),
                        items:
                            [
                              {'value': '0', 'label': 'Male'},
                              {'value': '1', 'label': 'Female'},
                            ].map((gender) {
                              return DropdownMenuItem(
                                value: gender['value'],
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 16.w,
                                  ),
                                  child: Text(
                                    gender['label']!, // Display as "Male" or "Female"
                                    style: InputStyles.textFieldStyle,
                                  ),
                                ),
                              );
                            }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedGender = value!;
                          });
                        },
                        icon: Icon(
                          Icons.arrow_drop_down,
                          color: ColorsManager.textLight,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: AppConstants.spacingL.h),

                  // Password Field
                  TextFormField(
                    controller: _passwordController,
                    decoration: InputStyles.passwordInput(
                      isObscureText: _isObscurePassword,
                      onToggle: () {
                        setState(() {
                          _isObscurePassword = !_isObscurePassword;
                        });
                      },
                    ),
                    style: InputStyles.textFieldStyle,
                    obscureText: _isObscurePassword,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a password';
                      }
                      if (value.length < AppConstants.passwordMinLength) {
                        return 'Password must be at least ${AppConstants.passwordMinLength} characters';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: AppConstants.spacingS.h),

                  // Password Strength Indicator
                  PasswordStrengthIndicator(password: _passwordController.text),
                  SizedBox(height: AppConstants.spacingL.h),

                  // Confirm Password Field
                  TextFormField(
                    controller: _confirmPasswordController,
                    decoration: InputStyles.passwordInput(
                      isObscureText: _isObscureConfirmPassword,
                      onToggle: () {
                        setState(() {
                          _isObscureConfirmPassword =
                              !_isObscureConfirmPassword;
                        });
                      },
                    ).copyWith(hintText: 'Confirm Password'),
                    style: InputStyles.textFieldStyle,
                    obscureText: _isObscureConfirmPassword,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please confirm your password';
                      }
                      if (value != _passwordController.text) {
                        return 'Passwords do not match';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: AppConstants.spacingXL.h),

                  // Create Account Button
                  Container(
                    width: double.infinity,
                    height: 56.h, // Increased height for modern design
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          ColorsManager.primaryBlue,
                          ColorsManager.primaryBlue.withValues(alpha: 0.8),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16.w),
                      boxShadow: [
                        BoxShadow(
                          color: ColorsManager.primaryBlue.withValues(
                            alpha: 0.3,
                          ),
                          blurRadius: 12,
                          offset: Offset(0, 6),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _handleSignup,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16.w),
                        ),
                      ),
                      child: _isLoading
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 20.w,
                                  height: 20.w,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white,
                                    ),
                                  ),
                                ),
                                SizedBox(width: AppConstants.spacingS.w),
                                Text(
                                  'Creating Account...',
                                  style: TextStyles.buttonLarge.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.person_add,
                                  color: Colors.white,
                                  size: 20.w,
                                ),
                                SizedBox(width: 8.w),
                                Text(
                                  'Create Account',
                                  style: TextStyles.buttonLarge.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),
                  SizedBox(height: AppConstants.spacingL.h),

                  // Sign In Link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Already have an account? ',
                        style: TextStyles.bodyMedium.copyWith(
                          color: ColorsManager.textSecondary,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          // Navigate to login screen
                          Navigator.pushReplacementNamed(
                            context,
                            Routes.loginScreen,
                          );
                        },
                        child: Text(
                          'Sign In',
                          style: TextStyles.linkMedium.copyWith(
                            decoration: TextDecoration.none,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: AppConstants.spacingXL.h,
                  ), // Added more space at bottom
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
