import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/doctor_provider.dart';
import '../../../core/networking/api_test.dart';

class ApiTestScreen extends StatefulWidget {
  const ApiTestScreen({super.key});

  @override
  State<ApiTestScreen> createState() => _ApiTestScreenState();
}

class _ApiTestScreenState extends State<ApiTestScreen> {
  bool _isLoading = false;
  String _testResults = '';
  String _apiStatus = 'Not tested';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('API Integration Test'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // API Connection Test
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'API Connection Test',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text('Status: $_apiStatus'),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _isLoading ? null : _runApiTests,
                      child: _isLoading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text('Run API Tests'),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Provider Integration Test
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Provider Integration Test',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    Consumer<DoctorProvider>(
                      builder: (context, provider, child) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Loading: ${provider.isLoading}'),
                            Text('Error: ${provider.errorMessage ?? 'None'}'),
                            Text(
                              'Specializations: ${provider.specializations.length}',
                            ),
                            Text('Doctors: ${provider.doctors.length}'),
                            const SizedBox(height: 8),
                            ElevatedButton(
                              onPressed: provider.isLoading
                                  ? null
                                  : () => _testProvider(provider),
                              child: const Text('Test Provider'),
                            ),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Test Results
            if (_testResults.isNotEmpty)
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Test Results',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 8),
                        Expanded(
                          child: SingleChildScrollView(
                            child: Text(
                              _testResults,
                              style: const TextStyle(fontFamily: 'monospace'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _runApiTests() async {
    setState(() {
      _isLoading = true;
      _testResults = '';
    });

    try {
      await ApiTest.runAllTests();
      setState(() {
        _apiStatus = '✅ Tests completed successfully';
        _testResults =
            'API tests completed successfully!\n\n'
            '✅ Base URL connection: OK\n'
            '✅ Specializations endpoint: OK\n'
            '✅ Auth endpoints: OK (422 expected for missing data)\n\n'
            'All API endpoints are accessible and responding correctly.';
      });
    } catch (e) {
      setState(() {
        _apiStatus = '❌ Tests failed';
        _testResults =
            'API tests failed:\n\n$e\n\n'
            'Please check:\n'
            '• Internet connection\n'
            '• API base URL\n'
            '• Backend server status';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _testProvider(DoctorProvider provider) async {
    try {
      await provider.refresh();
      setState(() {
        _testResults =
            'Provider test completed!\n\n'
            '✅ Specializations loaded: ${provider.specializations.length}\n'
            '✅ Doctors loaded: ${provider.doctors.length}\n'
            '✅ Loading state managed correctly\n'
            '✅ Error handling working\n\n'
            'Provider integration is working correctly!';
      });
    } catch (e) {
      setState(() {
        _testResults =
            'Provider test failed:\n\n$e\n\n'
            'Please check provider configuration and API service.';
      });
    }
  }
}
