import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theming/colors.dart';
import '../../../core/theming/text_styles.dart';
import '../../../core/constants/app_constants.dart';

class OnboardingPage extends StatelessWidget {
  final String title;
  final String subtitle;
  final String description;
  final String heroImage;
  final Color color;

  const OnboardingPage({
    super.key,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.heroImage,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: MediaQuery.of(context).size.height * 0.6,
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: AppConstants.screenPaddingHorizontal.w,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Hero Image (responsive height)
              SizedBox(
                height:
                    MediaQuery.of(context).size.height *
                    0.35, // Reduced from 0.45
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Background circle
                    Container(
                      width: 180.w, // Reduced from 200.w
                      height: 180.w, // Reduced from 200.w
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                    ),
                    // Hero image placeholder
                    Container(
                      width: 140.w, // Reduced from 160.w
                      height: 140.w, // Reduced from 160.w
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(70.w),
                      ),
                      child: Icon(
                        _getIconForPage(),
                        size: 70.w, // Reduced from 80.w
                        color: color,
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(
                height: AppConstants.spacingL.h,
              ), // Reduced from spacingXL
              // Title
              Text(
                title,
                style: TextStyles.headingSmall.copyWith(
                  color: ColorsManager.textPrimary,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),

              SizedBox(height: AppConstants.spacingS.h),

              // Subtitle
              Text(
                subtitle,
                style: TextStyles.titleMedium.copyWith(color: color),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),

              SizedBox(
                height: AppConstants.spacingM.h,
              ), // Reduced from spacingL
              // Description
              Text(
                description,
                style: TextStyles.bodyMedium.copyWith(
                  color: ColorsManager.textSecondary,
                ),
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getIconForPage() {
    // Return appropriate icons for each page type
    if (title.contains('Doctor')) return Icons.medical_services;
    if (title.contains('Find')) return Icons.search;
    if (title.contains('Book')) return Icons.calendar_today;
    if (title.contains('Health')) return Icons.health_and_safety;
    return Icons.medical_services; // Default
  }
}
