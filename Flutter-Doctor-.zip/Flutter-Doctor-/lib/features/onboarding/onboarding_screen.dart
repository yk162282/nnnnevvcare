import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/text_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../core/routing/routes.dart';
import 'widgets/onboarding_page.dart';
import 'widgets/onboarding_indicator.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  String? _loadingProvider; // Track which social login is loading

  final List<OnboardingPage> _pages = [
    OnboardingPage(
      title: 'Best Doctor Appointment App',
      subtitle: 'Your trusted healthcare companion',
      description:
          'Find the best doctors, book appointments, and manage your health with ease.',
      heroImage: 'assets/images/onboarding_doctor.png',
      color: ColorsManager.primaryBlue,
    ),
    OnboardingPage(
      title: 'Find Your Doctor',
      subtitle: 'Expert healthcare professionals',
      description:
          'Search and filter doctors by specialization, location, and availability.',
      heroImage: 'assets/images/onboarding_search.png',
      color: ColorsManager.lightBlue,
    ),
    OnboardingPage(
      title: 'Book Appointments',
      subtitle: 'Easy scheduling system',
      description:
          'Book appointments with your preferred doctors at convenient times.',
      heroImage: 'assets/images/onboarding_calendar.png',
      color: ColorsManager.primaryBlue,
    ),
    OnboardingPage(
      title: 'Health Management',
      subtitle: 'Track your wellness journey',
      description:
          'Keep track of your appointments, medical history, and health progress.',
      heroImage: 'assets/images/onboarding_health.png',
      color: ColorsManager.lightBlue,
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });
  }

  void _nextPage() {
    if (_currentPage < _pages.length - 1) {
      _pageController.nextPage(
        duration: AppConstants.animationDurationNormal,
        curve: Curves.easeInOut,
      );
    } else {
      _showAuthChooser();
    }
  }

  void _showAuthChooser() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.75,
      ),
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: ColorsManager.background,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24.w),
            topRight: Radius.circular(24.w),
          ),
        ),
        padding: EdgeInsets.all(AppConstants.spacingL.w),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle bar
              Container(
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: ColorsManager.lighterGray,
                  borderRadius: BorderRadius.circular(2.w),
                ),
              ),
              SizedBox(height: AppConstants.spacingL.h),

              // Header
              Text('Get Started', style: TextStyles.titleLarge),
              SizedBox(height: AppConstants.spacingM.h),

              Text(
                'Choose how you want to start your journey',
                style: TextStyles.bodyMedium.copyWith(
                  color: ColorsManager.textSecondary,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: AppConstants.spacingXL.h),

              // Modern Sign In Button
              Container(
                width: double.infinity,
                height: 56.h,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      ColorsManager.primaryBlue,
                      ColorsManager.primaryBlue.withValues(alpha: 0.8),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16.w),
                  boxShadow: [
                    BoxShadow(
                      color: ColorsManager.primaryBlue.withValues(alpha: 0.3),
                      blurRadius: 12,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pushReplacementNamed(context, Routes.loginScreen);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.w),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.login, color: Colors.white, size: 20.w),
                      SizedBox(width: 8.w),
                      Text(
                        'Sign In',
                        style: TextStyles.buttonLarge.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: AppConstants.spacingM.h),

              // Modern Sign Up Button
              Container(
                width: double.infinity,
                height: 56.h,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16.w),
                  border: Border.all(
                    color: ColorsManager.primaryBlue.withValues(alpha: 0.2),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 8,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pushReplacementNamed(
                      context,
                      Routes.signupScreen,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.w),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.person_add,
                        color: ColorsManager.primaryBlue,
                        size: 20.w,
                      ),
                      SizedBox(width: 8.w),
                      Text(
                        'Sign Up',
                        style: TextStyles.buttonLarge.copyWith(
                          color: ColorsManager.primaryBlue,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: AppConstants.spacingL.h),

              // Divider with "or" text
              Row(
                children: [
                  Expanded(
                    child: Divider(
                      color: ColorsManager.lighterGray,
                      thickness: 1,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: AppConstants.spacingM.w,
                    ),
                    child: Text(
                      'or sign up with',
                      style: TextStyles.bodySmall.copyWith(
                        color: ColorsManager.textSecondary,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Divider(
                      color: ColorsManager.lighterGray,
                      thickness: 1,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: AppConstants.spacingM.h,
              ), // Reduced from spacingL
              // Social Login Buttons
              Row(
                children: [
                  Expanded(
                    child: _buildSocialButton(
                      icon: 'assets/svgs/google.svg',
                      label: 'Google',
                      onPressed: () => _handleSocialLogin('google'),
                      color: const Color(
                        0xFF4285F4,
                      ), // Original Google blue color
                      isLoading: _loadingProvider == 'google',
                    ),
                  ),
                  SizedBox(width: AppConstants.spacingS.w), // Reduced spacing
                  Expanded(
                    child: _buildSocialButton(
                      icon: 'assets/svgs/facebook.svg',
                      label: 'Facebook',
                      onPressed: () => _handleSocialLogin('facebook'),
                      color: const Color(
                        0xFF1877F2,
                      ), // Official Facebook blue color
                      isLoading: _loadingProvider == 'facebook',
                    ),
                  ),
                  SizedBox(width: AppConstants.spacingS.w), // Reduced spacing
                  Expanded(
                    child: _buildSocialButton(
                      icon: 'assets/svgs/apple.svg',
                      label: 'Apple',
                      onPressed: () => _handleSocialLogin('apple'),
                      color: const Color(
                        0xFF000000,
                      ), // Official Apple black color
                      isLoading: _loadingProvider == 'apple',
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: AppConstants.spacingM.h,
              ), // Reduced from spacingL
              // Add bottom padding for safe area
              SizedBox(height: MediaQuery.of(context).padding.bottom),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSocialButton({
    required String icon,
    required String label,
    required VoidCallback onPressed,
    required Color color,
    bool isLoading = false,
  }) {
    return Container(
      height: 44.h, // Reduced from 48.h to prevent overflow
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.w), // Reduced from 12.w
        border: Border.all(color: ColorsManager.lighterGray, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.w), // Reduced from 12.w
          ),
        ),
        child: isLoading
            ? SizedBox(
                width: 16.w,
                height: 16.w,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                ),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset(
                    icon,
                    width: 18.w, // Reduced from 20.w
                    height: 18.w, // Reduced from 20.w
                    colorFilter: ColorFilter.mode(color, BlendMode.srcIn),
                  ),
                  SizedBox(height: 1.h), // Reduced from 2.h
                  Text(
                    label,
                    style: TextStyles.bodySmall.copyWith(
                      color: ColorsManager.textSecondary,
                      fontWeight: FontWeight.w500,
                      fontSize: 10.sp, // Added explicit font size
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  void _handleSocialLogin(String provider) async {
    try {
      // Set loading state
      setState(() {
        _loadingProvider = provider;
      });

      // Simulate social login API call
      await Future.delayed(const Duration(seconds: 2));

      // Handle different providers
      switch (provider.toLowerCase()) {
        case 'google':
          await _handleGoogleSignIn();
          break;
        case 'facebook':
          await _handleFacebookSignIn();
          break;
        case 'apple':
          await _handleAppleSignIn();
          break;
        default:
          throw Exception('Unknown provider: $provider');
      }
    } catch (e) {
      // Show error message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$provider sign-in failed: ${e.toString()}'),
            backgroundColor: ColorsManager.error,
          ),
        );
      }
    } finally {
      // Clear loading state
      if (mounted) {
        setState(() {
          _loadingProvider = null;
        });
      }
    }
  }

  Future<void> _handleGoogleSignIn() async {
    // TODO: Implement Google Sign-In with google_sign_in package
    // For now, simulate successful login
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      // Navigate to home screen after successful Google sign-in
      Navigator.pushReplacementNamed(context, Routes.homeScreen);
    }
  }

  Future<void> _handleFacebookSignIn() async {
    // TODO: Implement Facebook Sign-In with flutter_facebook_auth package
    // For now, simulate successful login
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      // Navigate to home screen after successful Facebook sign-in
      Navigator.pushReplacementNamed(context, Routes.homeScreen);
    }
  }

  Future<void> _handleAppleSignIn() async {
    // TODO: Implement Apple Sign-In with sign_in_with_apple package
    // For now, simulate successful login
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      // Navigate to home screen after successful Apple sign-in
      Navigator.pushReplacementNamed(context, Routes.homeScreen);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: ColorsManager.background,
        body: SafeArea(
          child: Column(
            children: [
              // Top Section with Brand
              Container(
                padding: EdgeInsets.all(AppConstants.spacingL.w),
                child: Row(
                  children: [
                    // Small Logo
                    Container(
                      width: 32.w,
                      height: 32.w,
                      decoration: BoxDecoration(
                        color: ColorsManager.primaryBlue,
                        borderRadius: BorderRadius.circular(16.w),
                      ),
                      child: Icon(
                        Icons.medical_services,
                        size: 18.w,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: AppConstants.spacingS.w),

                    // Brand Name
                    Text(
                      'VCare',
                      style: TextStyles.titleMedium.copyWith(
                        color: ColorsManager.primaryBlue,
                        fontWeight: FontWeight.w700,
                      ),
                    ),

                    const Spacer(),

                    // Skip Button
                    TextButton(
                      onPressed: _showAuthChooser,
                      child: Text(
                        'Skip',
                        style: TextStyles.linkMedium.copyWith(
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Page View
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  onPageChanged: _onPageChanged,
                  itemCount: _pages.length,
                  itemBuilder: (context, index) {
                    return _pages[index];
                  },
                ),
              ),

              // Bottom Section
              Container(
                padding: EdgeInsets.all(AppConstants.spacingL.w),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Page Indicator
                    OnboardingIndicator(
                      currentPage: _currentPage,
                      totalPages: _pages.length,
                    ),

                    SizedBox(height: AppConstants.spacingL.h),

                    // Next/Get Started Button
                    Container(
                      width: double.infinity,
                      height: 56.h,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            ColorsManager.primaryBlue,
                            ColorsManager.primaryBlue.withValues(alpha: 0.8),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16.w),
                        boxShadow: [
                          BoxShadow(
                            color: ColorsManager.primaryBlue.withValues(
                              alpha: 0.8,
                            ),
                            blurRadius: 12,
                            offset: Offset(0, 6),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: _nextPage,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.w),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              _currentPage == _pages.length - 1
                                  ? 'Get Started'
                                  : 'Next',
                              style: TextStyles.buttonLarge.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(width: 8.w),
                            Icon(
                              _currentPage == _pages.length - 1
                                  ? Icons.arrow_forward
                                  : Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 20.w,
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Add bottom safe area padding
                    SizedBox(height: MediaQuery.of(context).padding.bottom),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
