import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/text_styles.dart';
import '../../core/theming/button_styles.dart';
import '../../core/theming/input_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../core/routing/routes.dart';
import '../signup/widgets/password_strength_indicator.dart';

class CreateNewPasswordScreen extends StatefulWidget {
  const CreateNewPasswordScreen({super.key});

  @override
  State<CreateNewPasswordScreen> createState() =>
      _CreateNewPasswordScreenState();
}

class _CreateNewPasswordScreenState extends State<CreateNewPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _isObscurePassword = true;
  bool _isObscureConfirmPassword = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _handleCreatePassword() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // TODO: Implement actual password creation logic with API
        await Future.delayed(const Duration(seconds: 2)); // Simulate API call

        // Navigate to login screen after successful password creation
        if (mounted) {
          Navigator.pushNamedAndRemoveUntil(
            context,
            Routes.loginScreen,
            (route) => false,
          );
        }
      } catch (e) {
        // Handle error
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Password creation failed: ${e.toString()}'),
              backgroundColor: ColorsManager.error,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: ColorsManager.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: AppConstants.screenPaddingHorizontal.w,
            vertical: AppConstants.screenPaddingVertical.h,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Text('Create New Password', style: TextStyles.authTitle),
                SizedBox(height: AppConstants.spacingS.h),
                Text(
                  'Your new password must be different from previously used passwords.',
                  style: TextStyles.authSubtitle,
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // New Password Field
                TextFormField(
                  controller: _passwordController,
                  decoration: InputStyles.passwordInput(
                    isObscureText: _isObscurePassword,
                    onToggle: () {
                      setState(() {
                        _isObscurePassword = !_isObscurePassword;
                      });
                    },
                  ).copyWith(hintText: 'New Password'),
                  style: InputStyles.textFieldStyle,
                  obscureText: _isObscurePassword,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a new password';
                    }
                    if (value.length < AppConstants.passwordMinLength) {
                      return 'Password must be at least ${AppConstants.passwordMinLength} characters';
                    }
                    return null;
                  },
                ),
                SizedBox(height: AppConstants.spacingS.h),

                // Password Strength Indicator
                PasswordStrengthIndicator(password: _passwordController.text),
                SizedBox(height: AppConstants.spacingL.h),

                // Confirm Password Field
                TextFormField(
                  controller: _confirmPasswordController,
                  decoration: InputStyles.passwordInput(
                    isObscureText: _isObscureConfirmPassword,
                    onToggle: () {
                      setState(() {
                        _isObscureConfirmPassword = !_isObscureConfirmPassword;
                      });
                    },
                  ).copyWith(hintText: 'Confirm New Password'),
                  style: InputStyles.textFieldStyle,
                  obscureText: _isObscureConfirmPassword,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please confirm your new password';
                    }
                    if (value != _passwordController.text) {
                      return 'Passwords do not match';
                    }
                    return null;
                  },
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // Create Password Button
                SizedBox(
                  width: double.infinity,
                  height: AppConstants.primaryButtonHeight.h,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _handleCreatePassword,
                    style: _isLoading
                        ? ButtonStyles.loading
                        : ButtonStyles.primary,
                    child: _isLoading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 20.w,
                                height: 20.w,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(width: AppConstants.spacingS.w),
                              Text(
                                'Creating...',
                                style: TextStyles.buttonLarge,
                              ),
                            ],
                          )
                        : Text(
                            'Create Password',
                            style: TextStyles.buttonLarge,
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
