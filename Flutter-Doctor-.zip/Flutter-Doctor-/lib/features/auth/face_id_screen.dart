import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/text_styles.dart';
import '../../core/theming/button_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../core/routing/routes.dart';

class FaceIdScreen extends StatefulWidget {
  const FaceIdScreen({super.key});

  @override
  State<FaceIdScreen> createState() => _FaceIdScreenState();
}

class _FaceIdScreenState extends State<FaceIdScreen> {
  bool _isLoading = false;

  void _handleEnableBiometrics() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // TODO: Implement biometric enrollment via local_auth
      await Future.delayed(const Duration(seconds: 2)); // Simulate enrollment

      // Store flag biometricEnabled = true
      // Navigate to Home
      if (mounted) {
        Navigator.pushReplacementNamed(context, Routes.homeScreen);
      }
    } catch (e) {
      // Handle error
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Biometric setup failed: ${e.toString()}'),
            backgroundColor: ColorsManager.error,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _handleSkipBiometrics() {
    // Set flag biometricEnabled = false
    // Navigate to Home
    Navigator.pushReplacementNamed(context, Routes.homeScreen);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: AppConstants.screenPaddingHorizontal.w,
            vertical: AppConstants.screenPaddingVertical.h,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Large Icon/Illustration
              Container(
                width: 200.w,
                height: 200.w,
                decoration: BoxDecoration(
                  color: ColorsManager.lightBlue,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.face_retouching_natural,
                  size: 120.w,
                  color: ColorsManager.primaryBlue,
                ),
              ),
              SizedBox(height: AppConstants.spacingXL.h),

              // Title
              Text(
                'Face ID',
                style: TextStyles.authTitle,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: AppConstants.spacingL.h),

              // Description
              Text(
                'Enable Face ID for quick and secure access to your account. You can always change this later in settings.',
                style: TextStyles.authSubtitle,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: AppConstants.spacingXXL.h),

              // Enable Button
              SizedBox(
                width: double.infinity,
                height: AppConstants.primaryButtonHeight.h,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _handleEnableBiometrics,
                  style: _isLoading
                      ? ButtonStyles.loading
                      : ButtonStyles.primary,
                  child: _isLoading
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 20.w,
                              height: 20.w,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(width: AppConstants.spacingS.w),
                            Text(
                              'Setting Up...',
                              style: TextStyles.buttonLarge,
                            ),
                          ],
                        )
                      : Text('Enable Face ID', style: TextStyles.buttonLarge),
                ),
              ),
              SizedBox(height: AppConstants.spacingL.h),

              // Skip Button
              SizedBox(
                width: double.infinity,
                height: AppConstants.primaryButtonHeight.h,
                child: ElevatedButton(
                  onPressed: _handleSkipBiometrics,
                  style: ButtonStyles.outlined,
                  child: Text(
                    'Skip for Now',
                    style: TextStyles.buttonLarge.copyWith(
                      color: ColorsManager.primaryBlue,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
