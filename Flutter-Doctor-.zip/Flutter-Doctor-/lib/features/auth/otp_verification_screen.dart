import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/text_styles.dart';
import '../../core/theming/button_styles.dart';
import '../../core/theming/input_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../core/routing/routes.dart';

class OtpVerificationScreen extends StatefulWidget {
  const OtpVerificationScreen({super.key});

  @override
  State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends State<OtpVerificationScreen> {
  final List<TextEditingController> _otpControllers = List.generate(
    6,
    (index) => TextEditingController(),
  );
  final List<FocusNode> _focusNodes = List.generate(6, (index) => FocusNode());

  bool _isLoading = false;
  int _resendCountdown = 60;
  bool _canResend = false;

  @override
  void initState() {
    super.initState();
    _startResendCountdown();
  }

  @override
  void dispose() {
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  void _startResendCountdown() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted && _resendCountdown > 0) {
        setState(() {
          _resendCountdown--;
        });
        _startResendCountdown();
      } else if (mounted) {
        setState(() {
          _canResend = true;
        });
      }
    });
  }

  void _handleOtpInput(String value, int index) {
    if (value.length == 1 && index < 5) {
      _focusNodes[index + 1].requestFocus();
    }
  }

  void _handleBackspace(String value, int index) {
    if (value.isEmpty && index > 0) {
      _focusNodes[index - 1].requestFocus();
    }
  }

  void _handleVerifyOtp() async {
    final otp = _otpControllers.map((controller) => controller.text).join();

    if (otp.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter the complete 6-digit code'),
          backgroundColor: ColorsManager.error,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // TODO: Implement actual OTP verification logic with API
      await Future.delayed(const Duration(seconds: 2)); // Simulate API call

      // Navigate to next step (Create New Password or Face ID)
      if (mounted) {
        Navigator.pushReplacementNamed(context, Routes.createNewPasswordScreen);
      }
    } catch (e) {
      // Handle error
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('OTP verification failed: ${e.toString()}'),
            backgroundColor: ColorsManager.error,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _handleResendOtp() {
    if (!_canResend) return;

    setState(() {
      _canResend = false;
      _resendCountdown = 60;
    });

    // TODO: Implement resend OTP logic
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('OTP code resent successfully'),
        backgroundColor: ColorsManager.success,
      ),
    );

    _startResendCountdown();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: ColorsManager.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: AppConstants.screenPaddingHorizontal.w,
            vertical: AppConstants.screenPaddingVertical.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Text('OTP Verification', style: TextStyles.authTitle),
              SizedBox(height: AppConstants.spacingS.h),
              Text(
                'We\'ve sent a verification code to your email. Please enter the 6-digit code.',
                style: TextStyles.authSubtitle,
              ),
              SizedBox(height: AppConstants.spacingXL.h),

              // OTP Input Fields
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(6, (index) {
                  return SizedBox(
                    width: AppConstants.otpInputWidth.w,
                    height: AppConstants.otpInputHeight.h,
                    child: TextFormField(
                      controller: _otpControllers[index],
                      focusNode: _focusNodes[index],
                      decoration: InputStyles.otpInput,
                      style: InputStyles.textFieldStyle.copyWith(
                        fontSize: 18.sp,
                      ),
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      maxLength: 1,
                      onChanged: (value) {
                        _handleOtpInput(value, index);
                        _handleBackspace(value, index);
                      },
                      onFieldSubmitted: (value) =>
                          _handleOtpInput(value, index),
                      onEditingComplete: () {
                        if (index < 5) {
                          _focusNodes[index + 1].requestFocus();
                        }
                      },
                      textInputAction: index < 5
                          ? TextInputAction.next
                          : TextInputAction.done,
                    ),
                  );
                }),
              ),
              SizedBox(height: AppConstants.spacingXL.h),

              // Verify Button
              SizedBox(
                width: double.infinity,
                height: AppConstants.primaryButtonHeight.h,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _handleVerifyOtp,
                  style: _isLoading
                      ? ButtonStyles.loading
                      : ButtonStyles.primary,
                  child: _isLoading
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 20.w,
                              height: 20.w,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(width: AppConstants.spacingS.w),
                            Text('Verifying...', style: TextStyles.buttonLarge),
                          ],
                        )
                      : Text('Verify OTP', style: TextStyles.buttonLarge),
                ),
              ),
              SizedBox(height: AppConstants.spacingXL.h),

              // Resend Code Section
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Didn\'t receive the code? ',
                    style: TextStyles.bodyMedium.copyWith(
                      color: ColorsManager.textSecondary,
                    ),
                  ),
                  if (_canResend)
                    TextButton(
                      onPressed: _handleResendOtp,
                      child: Text(
                        'Resend',
                        style: TextStyles.linkMedium.copyWith(
                          decoration: TextDecoration.none,
                        ),
                      ),
                    )
                  else
                    Text(
                      'Resend code in ${_resendCountdown.toString().padLeft(2, '0')}:${(_resendCountdown % 60).toString().padLeft(2, '0')}',
                      style: TextStyles.bodySmall.copyWith(
                        color: ColorsManager.textLight,
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
