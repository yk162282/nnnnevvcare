import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/text_styles.dart';
import '../../core/theming/button_styles.dart';
import '../../core/theming/input_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../core/routing/routes.dart';
import '../../core/providers/user_provider.dart';

class FillProfileScreen extends StatefulWidget {
  final Map<String, String>? userData;

  const FillProfileScreen({super.key, this.userData});

  @override
  State<FillProfileScreen> createState() => _FillProfileScreenState();
}

class _FillProfileScreenState extends State<FillProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();

  DateTime? _selectedDate;
  bool _isLoading = false;
  String? _selectedAvatar;
  String? _selectedGender = '0'; // Default gender (0 for male, 1 for female - API format)

  @override
  void initState() {
    super.initState();
    _initializeFields();
  }

  void _initializeFields() {
    // Get user data from UserProvider first, then fall back to widget parameters
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userProvider = context.read<UserProvider>();
      final currentUser = userProvider.currentUser;
      
      if (currentUser != null) {
        // Pre-fill with existing user data from provider
        _nameController.text = currentUser.name;
        _emailController.text = currentUser.email;
        _phoneController.text = currentUser.phone;
        _selectedGender = currentUser.gender.toString();
      } else if (widget.userData != null) {
        // Fall back to data passed from signup
        _nameController.text = widget.userData!['name'] ?? '';
        _emailController.text = widget.userData!['email'] ?? '';
        _phoneController.text = widget.userData!['phone'] ?? '';
      }
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().subtract(
        const Duration(days: 6570),
      ), // 18 years ago
      firstDate: DateTime.now().subtract(
        const Duration(days: 36500),
      ), // 100 years ago
      lastDate: DateTime.now().subtract(
        const Duration(days: 6570),
      ), // 18 years ago
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _handleSubmit() async {
    if (_formKey.currentState!.validate() &&
        _selectedDate != null &&
        _selectedGender != null) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Get current user from provider
        final userProvider = context.read<UserProvider>();
        final currentUser = userProvider.currentUser;

        if (currentUser != null) {
          // Update existing user profile
          final updatedUser = currentUser.copyWith(
            name: _nameController.text.trim(),
            email: _emailController.text.trim(),
            phone: _phoneController.text.trim(),
            gender: int.parse(_selectedGender!),
            // Note: We're not updating image, createdAt, updatedAt here
            // as they should come from the API response
          );

          // Update the provider
          userProvider.updateUser(updatedUser);
        }

        // TODO: Implement actual profile update logic with API
        await Future.delayed(const Duration(seconds: 2)); // Simulate API call

        // Navigate to home screen after successful profile completion
        if (mounted) {
          Navigator.pushReplacementNamed(context, Routes.homeScreen);
        }
      } catch (e) {
        // Handle error
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Profile update failed: ${e.toString()}'),
              backgroundColor: ColorsManager.error,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    } else if (_selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select your birthday'),
          backgroundColor: ColorsManager.error,
        ),
      );
    } else if (_selectedGender == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select your gender'),
          backgroundColor: ColorsManager.error,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: ColorsManager.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: AppConstants.screenPaddingHorizontal.w,
            vertical: AppConstants.screenPaddingVertical.h,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Text('Fill Your Profile', style: TextStyles.authTitle),
                SizedBox(height: AppConstants.spacingS.h),
                Text(
                  'Please provide your information to complete your profile.',
                  style: TextStyles.authSubtitle,
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // Avatar Picker
                Center(
                  child: Stack(
                    children: [
                      Container(
                        width: AppConstants.avatarSizeLarge.w,
                        height: AppConstants.avatarSizeLarge.h,
                        decoration: BoxDecoration(
                          color: ColorsManager.lightBlue,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: ColorsManager.inputBorder,
                            width: 2,
                          ),
                        ),
                        child: _selectedAvatar != null
                            ? ClipOval(
                                child: Image.asset(
                                  _selectedAvatar!,
                                  fit: BoxFit.cover,
                                ),
                              )
                            : Icon(
                                Icons.person,
                                size: 60.w,
                                color: ColorsManager.primaryBlue,
                              ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          width: 32.w,
                          height: 32.w,
                          decoration: BoxDecoration(
                            color: ColorsManager.primaryBlue,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: ColorsManager.background,
                              width: 2,
                            ),
                          ),
                          child: Icon(
                            Icons.edit,
                            size: 16.w,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // Full Name Field
                TextFormField(
                  controller: _nameController,
                  decoration: InputStyles.nameInput,
                  style: InputStyles.textFieldStyle,
                  textCapitalization: TextCapitalization.words,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your full name';
                    }
                    if (value.length < AppConstants.nameMinLength) {
                      return 'Name must be at least ${AppConstants.nameMinLength} characters';
                    }
                    return null;
                  },
                ),
                SizedBox(height: AppConstants.spacingL.h),

                // Email Field
                TextFormField(
                  controller: _emailController,
                  decoration: InputStyles.emailInput.copyWith(
                    hintText: 'Email',
                  ),
                  style: InputStyles.textFieldStyle,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your email';
                    }
                    if (!RegExp(
                      r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                    ).hasMatch(value)) {
                      return 'Please enter a valid email';
                    }
                    return null;
                  },
                ),
                SizedBox(height: AppConstants.spacingL.h),

                // Birthday Field
                GestureDetector(
                  onTap: _selectDate,
                  child: Container(
                    height: AppConstants.inputFieldHeight.h,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: ColorsManager.inputBorder,
                        width: AppConstants.inputFieldBorderWidth,
                      ),
                      borderRadius: BorderRadius.circular(
                        AppConstants.inputFieldRadius.w,
                      ),
                      color: ColorsManager.inputBackground,
                    ),
                    padding: EdgeInsets.symmetric(
                      horizontal: AppConstants.spacingM.w,
                      vertical: AppConstants.spacingM.h,
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.calendar_today,
                          color: ColorsManager.textLight,
                          size: AppConstants.iconSizeMedium.w,
                        ),
                        SizedBox(width: AppConstants.spacingM.w),
                        Text(
                          _selectedDate != null
                              ? '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}'
                              : 'Select Birthday',
                          style: _selectedDate != null
                              ? InputStyles.textFieldStyle
                              : TextStyles.inputHint,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: AppConstants.spacingL.h),

                // Phone Field
                TextFormField(
                  controller: _phoneController,
                  decoration: InputStyles.phoneInput,
                  style: InputStyles.textFieldStyle,
                  keyboardType: TextInputType.phone,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your phone number';
                    }
                    if (value.length < AppConstants.phoneMinLength) {
                      return 'Phone number must be at least ${AppConstants.phoneMinLength} digits';
                    }
                    return null;
                  },
                ),
                SizedBox(height: AppConstants.spacingL.h),

                // Gender Selection
                Container(
                  height: AppConstants.inputFieldHeight.h,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: ColorsManager.inputBorder,
                      width: AppConstants.inputFieldBorderWidth,
                    ),
                    borderRadius: BorderRadius.circular(
                      AppConstants.inputFieldRadius.w,
                    ),
                    color: ColorsManager.inputBackground,
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: AppConstants.spacingM.w,
                    vertical: AppConstants.spacingM.h,
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedGender,
                      hint: Text('Select Gender', style: TextStyles.inputHint),
                      items: [
                        {'value': '0', 'label': 'Male'},
                        {'value': '1', 'label': 'Female'},
                      ].map((gender) {
                        return DropdownMenuItem(
                          value: gender['value'],
                          child: Text(
                            gender['label']!,
                            style: InputStyles.textFieldStyle,
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedGender = value;
                        });
                      },
                      icon: Icon(
                        Icons.arrow_drop_down,
                        color: ColorsManager.textLight,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // Submit Button
                SizedBox(
                  width: double.infinity,
                  height: AppConstants.primaryButtonHeight.h,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _handleSubmit,
                    style: _isLoading
                        ? ButtonStyles.loading
                        : ButtonStyles.primary,
                    child: _isLoading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 20.w,
                                height: 20.w,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(width: AppConstants.spacingS.w),
                              Text(
                                'Updating...',
                                style: TextStyles.buttonLarge,
                              ),
                            ],
                          )
                        : Text('Submit', style: TextStyles.buttonLarge),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
