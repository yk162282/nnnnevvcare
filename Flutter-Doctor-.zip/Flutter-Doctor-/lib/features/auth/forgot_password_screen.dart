import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/text_styles.dart';
import '../../core/theming/button_styles.dart';
import '../../core/theming/input_styles.dart';
import '../../core/constants/app_constants.dart';
import '../../core/routing/routes.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  void _handleResetPassword() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // TODO: Implement actual password reset logic with API
        await Future.delayed(const Duration(seconds: 2)); // Simulate API call
        
        // Navigate to OTP verification
        if (mounted) {
          Navigator.pushReplacementNamed(context, Routes.otpVerificationScreen);
        }
      } catch (e) {
        // Handle error
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Password reset failed: ${e.toString()}'),
              backgroundColor: ColorsManager.error,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: ColorsManager.textPrimary,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: AppConstants.screenPaddingHorizontal.w,
            vertical: AppConstants.screenPaddingVertical.h,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Text(
                  'Forgot Password',
                  style: TextStyles.authTitle,
                ),
                SizedBox(height: AppConstants.spacingS.h),
                Text(
                  'Enter your email address and we\'ll send you a code to reset your password.',
                  style: TextStyles.authSubtitle,
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // Email Field
                TextFormField(
                  controller: _emailController,
                  decoration: InputStyles.emailInput,
                  style: InputStyles.textFieldStyle,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your email';
                    }
                    if (!RegExp(
                      r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                    ).hasMatch(value)) {
                      return 'Please enter a valid email';
                    }
                    return null;
                  },
                ),
                SizedBox(height: AppConstants.spacingXL.h),

                // Reset Password Button
                SizedBox(
                  width: double.infinity,
                  height: AppConstants.primaryButtonHeight.h,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _handleResetPassword,
                    style: _isLoading ? ButtonStyles.loading : ButtonStyles.primary,
                    child: _isLoading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 20.w,
                                height: 20.w,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(width: AppConstants.spacingS.w),
                              Text(
                                'Sending...',
                                style: TextStyles.buttonLarge,
                              ),
                            ],
                          )
                        : Text(
                            'Reset Password',
                            style: TextStyles.buttonLarge,
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
