import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';
import 'package:doctor_appointment_app/core/theming/text_styles.dart';
import 'package:doctor_appointment_app/core/providers/doctor_provider.dart';
import 'package:doctor_appointment_app/core/providers/user_provider.dart';
import 'package:doctor_appointment_app/core/models/doctor.dart';
import 'package:doctor_appointment_app/core/models/specialization.dart';
import 'package:doctor_appointment_app/core/routing/routes.dart';
import 'package:doctor_appointment_app/features/home/widgets/specialty_card.dart';
import 'package:doctor_appointment_app/features/home/widgets/doctor_card.dart';
import 'package:doctor_appointment_app/features/home/widgets/bottom_navigation.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    // Load data when screen initializes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<DoctorProvider>();
      provider.refresh();
    });
  }

  void _handleNavigation(int index) {
    setState(() {
      _currentIndex = index;
    });

    // Navigate to different screens based on index (4-tab structure)
    switch (index) {
      case 0: // Home - already here
        break;
      case 1: // Find Doctors
        Navigator.pushNamed(context, Routes.doctorsScreen);
        break;
      case 2: // Appointments
        Navigator.pushNamed(context, Routes.appointmentsScreen);
        break;
      case 3: // Profile
        Navigator.pushNamed(context, Routes.profileScreen);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.background,
      body: SafeArea(
        child: Column(
          children: [
            // Main Content
            Expanded(
              child: Consumer<DoctorProvider>(
                builder: (context, provider, child) {
                  if (provider.isLoading && provider.doctors.isEmpty) {
                    return _buildLoadingState();
                  }

                  if (provider.errorMessage != null &&
                      provider.doctors.isEmpty) {
                    return _buildErrorState(provider);
                  }

                  return RefreshIndicator(
                    onRefresh: () => provider.refresh(),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Top Section (Header)
                          _buildHeader(),
                          SizedBox(height: 24.h),

                          // Banner Card
                          _buildBannerCard(),
                          SizedBox(height: 32.h),

                          // Doctor Specialties Section
                          _buildSpecialtiesSection(provider),
                          SizedBox(height: 32.h),

                          // Recommended Doctors Section
                          _buildRecommendedDoctorsSection(provider),
                          SizedBox(
                            height: 20.h,
                          ), // Reduced space for bottom navigation
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: EnhancedBottomNavigation(
        currentIndex: _currentIndex,
        onTap: _handleNavigation,
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: ColorsManager.primaryBlue),
          SizedBox(height: 16.h),
          Text(
            'Loading...',
            style: TextStyle(
              fontSize: 16.sp,
              color: ColorsManager.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(DoctorProvider provider) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 64.w, color: ColorsManager.error),
          SizedBox(height: 16.h),
          Text(
            'Error',
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.bold,
              color: ColorsManager.textPrimary,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            provider.errorMessage ?? 'Something went wrong',
            style: TextStyle(
              fontSize: 14.sp,
              color: ColorsManager.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 16.h),
          ElevatedButton(
            onPressed: () => provider.refresh(),
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorsManager.primaryBlue,
              foregroundColor: Colors.white,
            ),
            child: Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Consumer<UserProvider>(
      builder: (context, userProvider, child) {
        final userName = userProvider.currentUser?.name ?? 'User';

        return Padding(
          padding: EdgeInsets.only(left: 16.w, right: 16.w, top: 24.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Hi, $userName 👋',
                      style: TextStyles.authTitle.copyWith(
                        fontSize: 22.sp,
                        fontWeight: FontWeight.bold,
                        color: ColorsManager.textPrimary,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      'How are you feeling today?',
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: ColorsManager.textSecondary,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
              // Notification Button
              Container(
                width: 48.w,
                height: 48.w,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  onPressed: () {
                    Navigator.pushNamed(context, Routes.appointmentsScreen);
                  },
                  icon: Stack(
                    children: [
                      Icon(
                        Icons.notifications_outlined,
                        size: 24.w,
                        color: ColorsManager.textLight,
                      ),
                      // Notification badge
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          width: 8.w,
                          height: 8.w,
                          decoration: BoxDecoration(
                            color: ColorsManager.primaryBlue,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBannerCard() {
    return GestureDetector(
      onTap: () {
        // Navigate to doctors screen when banner is tapped
        Navigator.pushNamed(context, Routes.doctorsScreen);
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 16.w),
        height: 180.h,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Blue Card
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(20.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16.w),
                image: const DecorationImage(
                  image: AssetImage('assets/images/home_blue_pattern.png'),
                  fit: BoxFit.cover,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF2196F3).withValues(alpha: 0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Book and\nschedule with\nnearest doctor',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w600,
                            height: 1.3,
                          ),
                        ),
                        SizedBox(height: 16.h),
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 16.w,
                            vertical: 8.h,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(25.w),
                          ),
                          child: Text(
                            'Book Now',
                            style: TextStyle(
                              color: ColorsManager.primaryBlue,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 100.w), // Space for the image
                ],
              ),
            ),

            // Doctor Image (overlapping right side)
            Positioned(
              right: 40.w,
              bottom: 0.h,
              child: Image.asset(
                'assets/images/doctor_banner.png',
                height: 220.h,
                fit: BoxFit.contain,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpecialtiesSection(DoctorProvider provider) {
    if (provider.specializations.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(left: 16.w, right: 16.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Doctor Speciality',
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: ColorsManager.textPrimary,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    'Find your specialist',
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: ColorsManager.textSecondary,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, Routes.doctorsScreen);
                },
                child: Text(
                  'See All',
                  style: TextStyle(
                    color: ColorsManager.primaryBlue,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16.h),
        SizedBox(
          height: 130.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            itemCount: provider.specializations.length,
            itemBuilder: (context, index) {
              final specialty = provider.specializations[index];
              return Container(
                width: 100.w,
                margin: EdgeInsets.only(right: 12.w),
                child: SpecialtyCard(
                  specialty: _convertSpecializationToMap(specialty),
                  onTap: () {
                    // Navigate to specialty detail screen
                    provider.loadDoctorsBySpecialization(specialty.id);
                    Navigator.pushNamed(context, Routes.doctorsScreen);
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildRecommendedDoctorsSection(DoctorProvider provider) {
    if (provider.recommendedDoctors.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Recommended Doctor',
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: ColorsManager.textPrimary,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    'Top-rated doctors near you',
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: ColorsManager.textSecondary,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, Routes.doctorsScreen);
                },
                child: Text(
                  'See All',
                  style: TextStyle(
                    color: ColorsManager.primaryBlue,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16.h),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          itemCount: provider.recommendedDoctors.length,
          itemBuilder: (context, index) {
            final doctor = provider.recommendedDoctors[index];
            return Container(
              margin: EdgeInsets.only(bottom: 12.h),
              child: DoctorCard(
                doctor: _convertDoctorToMap(doctor),
                onTap: () {
                  // Navigate to doctor detail screen
                  provider.selectDoctor(doctor);
                  Navigator.pushNamed(context, Routes.doctorDetailScreen);
                },
              ),
            );
          },
        ),
      ],
    );
  }

  // Helper methods to convert models to maps for backward compatibility
  Map<String, dynamic> _convertSpecializationToMap(
    Specialization specialization,
  ) {
    return {
      'name': specialization.name,
      'icon': Icons.medical_services,
      'color': ColorsManager.primaryBlue.withOpacity(0.1),
    };
  }

  Map<String, dynamic> _convertDoctorToMap(Doctor doctor) {
    return {
      'name': doctor.name,
      'specialty': doctor.specialization?.name ?? 'Specialist',
      'hospital': doctor.city ?? 'Hospital',
      'rating': doctor.rating ?? 0.0,
      'image': doctor.image,
    };
  }
}
