import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';
import '../widgets/home_header.dart';
import '../widgets/quick_actions.dart';
import '../widgets/featured_doctors.dart';
import '../widgets/recent_appointments.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.moreLightGray,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with user info and notifications
              const HomeHeader(),

              SizedBox(height: 30.h),

              // Quick Actions
              const QuickActions(),

              SizedBox(height: 30.h),

              // Featured Doctors
              const FeaturedDoctors(),

              SizedBox(height: 30.h),

              // Recent Appointments
              const RecentAppointments(),
            ],
          ),
        ),
      ),
    );
  }
}
