import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';
import '../../../../core/routing/routes.dart';

class FeaturedDoctors extends StatelessWidget {
  const FeaturedDoctors({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Featured Doctors',
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, Routes.doctorsScreen);
              },
              child: Text(
                'View All',
                style: TextStyle(
                  color: ColorsManager.mainBlue,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 20.h),
        SizedBox(
          height: 200.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 5,
            itemBuilder: (context, index) {
              return _buildDoctorCard(context, index);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDoctorCard(BuildContext context, int index) {
    final doctors = [
      {
        'name': 'Dr. Sarah Johnson',
        'specialization': 'Cardiologist',
        'rating': 4.8,
        'experience': '15 years',
        'image': 'assets/images/doctor1.jpg',
      },
      {
        'name': 'Dr. Michael Chen',
        'specialization': 'Neurologist',
        'rating': 4.9,
        'experience': '12 years',
        'image': 'assets/images/doctor2.jpg',
      },
      {
        'name': 'Dr. Emily Davis',
        'specialization': 'Pediatrician',
        'rating': 4.7,
        'experience': '8 years',
        'image': 'assets/images/doctor3.jpg',
      },
      {
        'name': 'Dr. Robert Wilson',
        'specialization': 'Orthopedic',
        'rating': 4.6,
        'experience': '20 years',
        'image': 'assets/images/doctor4.jpg',
      },
      {
        'name': 'Dr. Lisa Brown',
        'specialization': 'Dermatologist',
        'rating': 4.8,
        'experience': '10 years',
        'image': 'assets/images/doctor5.jpg',
      },
    ];

    final doctor = doctors[index];

    return Container(
      width: 160.w,
      margin: EdgeInsets.only(right: 16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Doctor Image
          Container(
            height: 100.h,
            decoration: BoxDecoration(
              color: ColorsManager.lightBlue,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16.w),
                topRight: Radius.circular(16.w),
              ),
            ),
            child: Center(
              child: Icon(
                Icons.medical_services,
                size: 40.w,
                color: ColorsManager.mainBlue,
              ),
            ),
          ),

          // Doctor Info
          Padding(
            padding: EdgeInsets.all(12.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  doctor['name'] as String,
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 4.h),
                Text(
                  doctor['specialization'] as String,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: ColorsManager.gray,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Icon(
                      Icons.star,
                      size: 14.w,
                      color: Colors.amber,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      '${doctor['rating']}',
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      doctor['experience'] as String,
                      style: TextStyle(
                        fontSize: 10.sp,
                        color: ColorsManager.gray,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
