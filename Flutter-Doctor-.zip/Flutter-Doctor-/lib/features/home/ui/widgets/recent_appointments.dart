import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';
import '../../../../core/routing/routes.dart';

class RecentAppointments extends StatelessWidget {
  const RecentAppointments({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Appointments',
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, Routes.appointmentsScreen);
              },
              child: Text(
                'View All',
                style: TextStyle(
                  color: ColorsManager.mainBlue,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 20.h),
        _buildAppointmentList(context),
      ],
    );
  }

  Widget _buildAppointmentList(BuildContext context) {
    final appointments = [
      {
        'doctorName': 'Dr. Sarah Johnson',
        'specialization': 'Cardiologist',
        'date': 'Today, 2:00 PM',
        'status': 'confirmed',
        'type': 'In-person',
      },
      {
        'doctorName': 'Dr. Michael Chen',
        'specialization': 'Neurologist',
        'date': 'Tomorrow, 10:00 AM',
        'status': 'pending',
        'type': 'Video Call',
      },
      {
        'doctorName': 'Dr. Emily Davis',
        'specialization': 'Pediatrician',
        'date': 'Dec 25, 3:30 PM',
        'status': 'confirmed',
        'type': 'In-person',
      },
    ];

    return Column(
      children: appointments.map((appointment) {
        return _buildAppointmentCard(context, appointment);
      }).toList(),
    );
  }

  Widget _buildAppointmentCard(BuildContext context, Map<String, String> appointment) {
    final status = appointment['status'] as String;
    final statusColor = _getStatusColor(status);
    final statusText = _getStatusText(status);

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          // Doctor Avatar
          Container(
            width: 50.w,
            height: 50.w,
            decoration: BoxDecoration(
              color: ColorsManager.lightBlue,
              borderRadius: BorderRadius.circular(25.w),
            ),
            child: Icon(
              Icons.medical_services,
              color: ColorsManager.mainBlue,
              size: 24.w,
            ),
          ),

          SizedBox(width: 16.w),

          // Appointment Details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  appointment['doctorName'] as String,
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  appointment['specialization'] as String,
                  style: TextStyle(
                    fontSize: 14.sp,
                    color: ColorsManager.gray,
                  ),
                ),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      size: 14.w,
                      color: ColorsManager.gray,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      appointment['date'] as String,
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: ColorsManager.gray,
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Icon(
                      Icons.video_call,
                      size: 14.w,
                      color: ColorsManager.gray,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      appointment['type'] as String,
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: ColorsManager.gray,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Status Badge
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20.w),
            ),
            child: Text(
              statusText,
              style: TextStyle(
                color: statusColor,
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'confirmed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      default:
        return ColorsManager.gray;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'confirmed':
        return 'Confirmed';
      case 'pending':
        return 'Pending';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  }
}
