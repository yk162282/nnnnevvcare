import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';

class DoctorCard extends StatelessWidget {
  final Map<String, dynamic> doctor;
  final VoidCallback onTap;

  const DoctorCard({
    super.key,
    required this.doctor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 12.h),
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.w),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Doctor image
            Container(
              width: 70.w,
              height: 70.w,
              decoration: BoxDecoration(
                color: ColorsManager.lightBlue,
                shape: BoxShape.circle,
                border: Border.all(
                  color: ColorsManager.inputBorder,
                  width: 2,
                ),
              ),
              child: ClipOval(
                child: doctor['image'] != null
                    ? Image.asset(
                        doctor['image']!,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(
                            Icons.person,
                            size: 40.w,
                            color: ColorsManager.primaryBlue,
                          );
                        },
                      )
                    : Icon(
                        Icons.person,
                        size: 40.w,
                        color: ColorsManager.primaryBlue,
                      ),
              ),
            ),
            SizedBox(width: 16.w),
            // Doctor information
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    doctor['name'] ?? 'Dr. Unknown',
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: ColorsManager.textPrimary,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    doctor['specialty'] ?? 'Specialist',
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: ColorsManager.textSecondary,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    doctor['hospital'] ?? 'Hospital',
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: ColorsManager.textLight,
                    ),
                  ),
                ],
              ),
            ),
            // Rating
            Column(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.star,
                      size: 16.w,
                      color: Colors.amber,
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      '${doctor['rating'] ?? 0.0}',
                      style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold,
                        color: ColorsManager.textPrimary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
