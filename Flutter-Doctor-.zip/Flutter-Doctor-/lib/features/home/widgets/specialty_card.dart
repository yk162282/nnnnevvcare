import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';

class SpecialtyCard extends StatelessWidget {
  final Map<String, dynamic> specialty;
  final VoidCallback onTap;

  const SpecialtyCard({
    super.key,
    required this.specialty,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 80.w,
        margin: EdgeInsets.only(right: 16.w),
        child: Column(
          children: [
            // Circular icon container
            Container(
              width: 60.w,
              height: 60.w,
              decoration: BoxDecoration(
                color: const Color(0xFFE3F2FD),
                shape: BoxShape.circle,
                border: Border.all(
                  color: specialty['color'] ?? Colors.blue,
                  width: 2,
                ),
              ),
              child: Icon(
                specialty['icon'] ?? Icons.medical_services,
                size: 30.w,
                color: specialty['color'] ?? Colors.blue,
              ),
            ),
            SizedBox(height: 8.h),
            // Specialty name
            Text(
              specialty['name'] ?? 'Specialty',
              style: TextStyle(
                fontSize: 12.sp,
                color: ColorsManager.textSecondary,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
