import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:doctor_appointment_app/core/theming/colors.dart';
import 'package:doctor_appointment_app/core/theming/text_styles.dart';
import 'package:doctor_appointment_app/core/models/doctor.dart';

class RecommendedDoctorCard extends StatelessWidget {
  final Doctor doctor;
  final VoidCallback onTap;

  const RecommendedDoctorCard({
    super.key,
    required this.doctor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 160.w,
        margin: EdgeInsets.only(right: 16.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16.w),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Doctor image
            Container(
              height: 120.h,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16.w),
                  topRight: Radius.circular(16.w),
                ),
                color: ColorsManager.lightBlue,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16.w),
                  topRight: Radius.circular(16.w),
                ),
                child: doctor.image != null
                    ? Image.network(
                        doctor.image!,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(
                            Icons.person,
                            size: 60.w,
                            color: ColorsManager.primaryBlue,
                          );
                        },
                      )
                    : Icon(
                        Icons.person,
                        size: 60.w,
                        color: ColorsManager.primaryBlue,
                      ),
              ),
            ),

            // Doctor info
            Padding(
              padding: EdgeInsets.all(12.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    doctor.name,
                    style: TextStyles.bodyMedium.copyWith(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: ColorsManager.textPrimary,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    doctor.specialization?.name ?? 'Specialist',
                    style: TextStyles.bodySmall.copyWith(
                      fontSize: 12.sp,
                      color: ColorsManager.textSecondary,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 8.h),

                  // Rating and reviews
                  Row(
                    children: [
                      Icon(Icons.star, size: 14.w, color: Colors.amber),
                      SizedBox(width: 4.w),
                      Text(
                        doctor.rating?.toStringAsFixed(1) ?? '0.0',
                        style: TextStyles.bodySmall.copyWith(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: ColorsManager.textPrimary,
                        ),
                      ),
                      if (doctor.reviewCount != null) ...[
                        SizedBox(width: 4.w),
                        Text(
                          '(${doctor.reviewCount})',
                          style: TextStyles.bodySmall.copyWith(
                            fontSize: 10.sp,
                            color: ColorsManager.textSecondary,
                          ),
                        ),
                      ],
                    ],
                  ),

                  SizedBox(height: 8.h),

                  // Availability indicator
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 8.w,
                      vertical: 4.h,
                    ),
                    decoration: BoxDecoration(
                      color: doctor.isAvailable
                          ? ColorsManager.success.withValues(alpha: 0.1)
                          : ColorsManager.error.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12.w),
                    ),
                    child: Text(
                      doctor.isAvailable ? 'Available' : 'Busy',
                      style: TextStyles.bodySmall.copyWith(
                        fontSize: 10.sp,
                        color: doctor.isAvailable
                            ? ColorsManager.success
                            : ColorsManager.error,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
