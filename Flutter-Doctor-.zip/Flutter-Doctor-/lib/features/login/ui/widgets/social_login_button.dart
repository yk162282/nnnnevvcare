import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/theming/colors.dart';

class SocialLoginButton extends StatelessWidget {
  final String provider;
  final IconData icon;
  final VoidCallback onPressed;

  const SocialLoginButton({
    super.key,
    required this.provider,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 60.w, // Fixed width to prevent overflow
      height: 44.h, // Reduced height to prevent overflow
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.w),
        border: Border.all(color: ColorsManager.lighterGray, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.w),
          ),
        ),
        child: Icon(icon, size: 20.w, color: _getProviderColor()),
      ),
    );
  }

  Color _getProviderColor() {
    switch (provider.toLowerCase()) {
      case 'google':
        return const Color(0xFF4285F4); // Original Google blue
      case 'facebook':
        return const Color(0xFF1877F2); // Official Facebook blue
      case 'apple':
        return const Color(0xFF000000); // Official Apple black
      default:
        return ColorsManager.textPrimary;
    }
  }
}
