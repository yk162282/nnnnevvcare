import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../core/theming/colors.dart';
import '../../../core/theming/text_styles.dart';
import '../../../core/theming/input_styles.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/routing/routes.dart';
import '../../../core/providers/user_provider.dart';
import '../../../core/helpers/spacing.dart';
import '../../../core/di/dependency_injection.dart';
import '../../../core/networking/api_service_interface.dart';
import '../data/models/user_profile.dart';
import 'widgets/remember_me_checkbox.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool isObscureText = true;
  bool rememberMe = false;
  bool isLoading = false;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void _handleLogin() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });

      try {
        // Get API service from dependency injection
        final apiService = getIt<ApiServiceInterface>();

        // Call the real login API
        final response = await apiService.login(
          email: emailController.text.trim(),
          password: passwordController.text,
        );

        if (response.isSuccess && response.data != null) {
          // Extract user data and token from response
          final userData = response.data!;

          // Create user profile from API response
          final user = UserProfile(
            id: userData['id'] ?? 1,
            name: userData['name'] ?? emailController.text.split('@')[0],
            email: userData['email'] ?? emailController.text,
            phone: userData['phone'] ?? '+1234567890',
            gender: userData['gender'] ?? 0,
            image: userData['image'],
            createdAt: userData['created_at'] != null
                ? DateTime.parse(userData['created_at'])
                : DateTime.now(),
            updatedAt: userData['updated_at'] != null
                ? DateTime.parse(userData['updated_at'])
                : DateTime.now(),
          );

          // Set the user in the provider
          final userProvider = context.read<UserProvider>();
          userProvider.setUser(user);

          // Store authentication token if provided
          if (userData['token'] != null) {
            // TODO: Store token securely (SharedPreferences or secure storage)
            print('Auth token: ${userData['token']}');
          }

          // Navigate to home screen
          if (mounted) {
            Navigator.pushReplacementNamed(context, Routes.homeScreen);
          }
        } else {
          // Handle API error response
          final errorMessage =
              response.message ??
              'Login failed. Please check your credentials.';
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(errorMessage),
                backgroundColor: ColorsManager.error,
              ),
            );
          }
        }
      } catch (e) {
        // Handle network or other errors
        String errorMessage = 'Login failed. Please try again.';

        if (e.toString().contains('Connection failed') ||
            e.toString().contains('Network is unreachable')) {
          errorMessage = 'No internet connection. Please check your network.';
        } else if (e.toString().contains('timeout')) {
          errorMessage = 'Request timeout. Please try again.';
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: ColorsManager.error,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
      }
    }
  }

  void _handleForgotPassword() {
    Navigator.pushNamed(context, Routes.forgotPasswordScreen);
  }

  void _clearErrors() {
    // Clear any previous error messages when user starts typing
    setState(() {
      // This will trigger a rebuild and clear any error states
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Show confirmation dialog when back button is pressed
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Exit App'),
            content: const Text('Are you sure you want to exit the app?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Exit'),
              ),
            ],
          ),
        );
        return shouldPop ?? false;
      },
      child: Scaffold(
        backgroundColor: ColorsManager.background,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(
              horizontal: AppConstants.screenPaddingHorizontal.w,
              vertical: AppConstants.screenPaddingVertical.h,
            ),
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Text('Welcome Back', style: TextStyles.authTitle),
                  verticalSpace(AppConstants.spacingS.h),
                  Text(
                    'We\'re excited to have you back, can\'t wait to see what you\'ve been up to since you last logged in.',
                    style: TextStyles.authSubtitle,
                  ),
                  verticalSpace(AppConstants.spacingXL.h),

                  // Email Field
                  TextFormField(
                    controller: emailController,
                    decoration: InputStyles.emailInput,
                    style: InputStyles.textFieldStyle,
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (_) => _clearErrors(),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your email';
                      }
                      if (!RegExp(
                        r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                      ).hasMatch(value)) {
                        return 'Please enter a valid email';
                      }
                      return null;
                    },
                  ),
                  verticalSpace(AppConstants.spacingL.h),

                  // Password Field
                  TextFormField(
                    controller: passwordController,
                    decoration: InputStyles.passwordInput(
                      isObscureText: isObscureText,
                      onToggle: () {
                        setState(() {
                          isObscureText = !isObscureText;
                        });
                      },
                    ),
                    style: InputStyles.textFieldStyle,
                    obscureText: isObscureText,
                    onChanged: (_) => _clearErrors(),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your password';
                      }
                      if (value.length < AppConstants.passwordMinLength) {
                        return 'Password must be at least ${AppConstants.passwordMinLength} characters';
                      }
                      return null;
                    },
                  ),
                  verticalSpace(AppConstants.spacingL.h),

                  // Remember Me & Forgot Password Row
                  Row(
                    children: [
                      // Remember Me Checkbox
                      Expanded(
                        child: RememberMeCheckbox(
                          value: rememberMe,
                          onChanged: (value) {
                            setState(() {
                              rememberMe = value ?? false;
                            });
                          },
                        ),
                      ),

                      // Forgot Password Link
                      TextButton(
                        onPressed: _handleForgotPassword,
                        child: Text(
                          'Forgot Password?',
                          style: TextStyles.linkMedium.copyWith(
                            decoration: TextDecoration.none,
                          ),
                        ),
                      ),
                    ],
                  ),
                  verticalSpace(AppConstants.spacingXL.h),

                  // Login Button
                  Container(
                    width: double.infinity,
                    height: 56.h, // Increased height for modern design
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          ColorsManager.primaryBlue,
                          ColorsManager.primaryBlue.withValues(alpha: 0.8),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16.w),
                      boxShadow: [
                        BoxShadow(
                          color: ColorsManager.primaryBlue.withValues(
                            alpha: 0.3,
                          ),
                          blurRadius: 12,
                          offset: Offset(0, 6),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: isLoading ? null : _handleLogin,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16.w),
                        ),
                      ),
                      child: isLoading
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 20.w,
                                  height: 20.w,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white,
                                    ),
                                  ),
                                ),
                                SizedBox(width: AppConstants.spacingS.w),
                                Text(
                                  'Signing In...',
                                  style: TextStyles.buttonLarge.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.login,
                                  color: Colors.white,
                                  size: 20.w,
                                ),
                                SizedBox(width: 8.w),
                                Text(
                                  'Sign In',
                                  style: TextStyles.buttonLarge.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),
                  verticalSpace(AppConstants.spacingL.h),

                  // Sign Up Link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Don\'t have an account? ',
                        style: TextStyles.bodyMedium.copyWith(
                          color: ColorsManager.textSecondary,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, Routes.signupScreen);
                        },
                        child: Text(
                          'Sign Up',
                          style: TextStyles.linkMedium.copyWith(
                            decoration: TextDecoration.none,
                          ),
                        ),
                      ),
                    ],
                  ),
                  verticalSpace(
                    AppConstants.spacingXL.h,
                  ), // Added more space at bottom
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
