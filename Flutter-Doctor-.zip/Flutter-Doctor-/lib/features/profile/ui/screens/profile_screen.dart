import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../../core/providers/user_provider.dart';
import '../../../../core/theming/colors.dart';
import '../../../../core/routing/routes.dart';
import '../../../login/data/models/user_profile.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Profile',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 20.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black87),
      ),
      body: Consumer<UserProvider>(
        builder: (context, userProvider, child) {
          final user = userProvider.currentUser;

          return SingleChildScrollView(
            padding: EdgeInsets.all(20.w),
            child: Column(
              children: [
                // Profile Header
                _buildProfileHeader(user),
                SizedBox(height: 30.h),

                // Profile Options
                _buildProfileOptions(context, userProvider),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildProfileHeader(UserProfile? user) {
    return Center(
      child: Column(
        children: [
          // Profile Picture
          Container(
            width: 100.w,
            height: 100.w,
            decoration: BoxDecoration(
              color: ColorsManager.mainBlue,
              borderRadius: BorderRadius.circular(50.w),
            ),
            child: Icon(Icons.person, color: Colors.white, size: 50.w),
          ),
          SizedBox(height: 16.h),

          // User Name
          Text(
            user?.name ?? 'User Name',
            style: TextStyle(
              fontSize: 24.sp,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 8.h),

          // User Email
          Text(
            user?.email ?? 'user@example.com',
            style: TextStyle(fontSize: 16.sp, color: ColorsManager.gray),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileOptions(BuildContext context, UserProvider userProvider) {
    final options = [
      {
        'title': 'Personal Information',
        'icon': Icons.person_outline,
        'route': Routes.personalInfoScreen,
      },
      {
        'title': 'Medical History',
        'icon': Icons.medical_services,
        'route': null,
      },
      {
        'title': 'Appointments',
        'icon': Icons.calendar_today,
        'route': Routes.appointmentsScreen,
      },
      {'title': 'Settings', 'icon': Icons.settings, 'route': null},
      {'title': 'Help & Support', 'icon': Icons.help_outline, 'route': null},
      {'title': 'Logout', 'icon': Icons.logout, 'route': null},
    ];

    return Column(
      children: options.map((option) {
        return _buildOptionTile(
          context,
          title: option['title'] as String,
          icon: option['icon'] as IconData,
          route: option['route'] as String?,
          onTap: () {
            if (option['title'] == 'Logout') {
              _handleLogout(context, userProvider);
            } else if (option['route'] != null) {
              Navigator.pushNamed(context, option['route'] as String);
            } else {
              // TODO: Handle other options
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${option['title']} coming soon!'),
                  duration: const Duration(seconds: 2),
                ),
              );
            }
          },
        );
      }).toList(),
    );
  }

  void _handleLogout(BuildContext context, UserProvider userProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              userProvider.logout();
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, Routes.loginScreen);
            },
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  Widget _buildOptionTile(
    BuildContext context, {
    required String title,
    required IconData icon,
    String? route,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ListTile(
        leading: Container(
          width: 40.w,
          height: 40.w,
          decoration: BoxDecoration(
            color: ColorsManager.lightBlue,
            borderRadius: BorderRadius.circular(12.w),
          ),
          child: Icon(icon, color: ColorsManager.mainBlue, size: 20.w),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          size: 16.w,
          color: ColorsManager.gray,
        ),
        onTap: onTap,
      ),
    );
  }
}
